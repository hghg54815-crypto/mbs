# MPS — TD

Maintenance Operations is an English-only maintenance, inventory, work-order, and reporting workspace with a public maintenance-request form.

## Run and operate

- Install dependencies: `pnpm install`
- Start the API: `pnpm --filter @workspace/api-server run dev`
- Start the web app: `pnpm --filter @workspace/mps-td run dev`
- Start the component preview: `pnpm --filter @workspace/mockup-sandbox run dev`
- Generate the Prisma client: `pnpm --filter @workspace/api-server run db:generate`
- Apply the Prisma schema to the development database: `pnpm --filter @workspace/api-server run db:push`
- Load demo operational records: `pnpm --filter @workspace/api-server run db:seed`
- Generate a new development-only test administrator credential: `NODE_ENV=development pnpm --filter @workspace/api-server run db:provision-test-account`
- Regenerate API clients and validation schemas: `pnpm --filter @workspace/api-spec run codegen`
- Typecheck the workspace: `pnpm run typecheck`
- Build the API: `pnpm --filter @workspace/api-server run build`
- Build the main web app: `PORT=5000 BASE_PATH=/ pnpm --filter @workspace/mps-td run build`
- Build the component preview: `PORT=5000 BASE_PATH=/__mockup pnpm --filter @workspace/mockup-sandbox run build`

Vite artifact builds require `PORT` and `BASE_PATH`; set `BASE_PATH` to the artifact's registered preview path.

## Required environment

- `DATABASE_URL`: PostgreSQL connection used by the API server and Prisma.
- `SESSION_SECRET`: private application secret used to hash local session tokens and session tokens. Configure it through Replit Secrets; do not commit it.

## Authentication and accounts

- Staff accounts are employee records in PostgreSQL. Passwords are stored as salted scrypt hashes, never as plain text.
- Sign-in uses email plus a temporary password; the first successful sign-in requires a replacement password of at least 12 characters.
- Sessions are random opaque tokens stored as hashes in PostgreSQL and sent in HTTP-only, same-site cookies.
- Administrators create or reset employee accounts at **Employees**. Deliver temporary passwords to staff through a private channel.
- The development-only provisioning command creates a test administrator and prints its one-time temporary password. It refuses to run when `NODE_ENV=production`.
- Roles: Admin, Supervisor, Storekeeper, Technician and **Manager** (read-only, sees every region). Anyone with more than one region can switch regions from the top bar.
- Employee accounts (Admin → Employees) can be searched, added, edited and deleted. Duplicate IDs and emails are rejected; a password reset ends the employee's sessions. Employees with linked records (requests, job cards, stock movements) cannot be deleted.
- Maintenance requesters are **not** staff and never sign in. The first request from a new email is saved as `Pending Verification` and appears under **Requests → Email verification** for an Admin. Verifying the email releases the waiting requests; later requests from that email are accepted directly. Rejecting blocks the email. There are no one-time codes and no email service is needed.
- Public-form limits: 3 waiting requests per unverified email, 10 requests per hour per verified email, 20 new unverified emails per hour overall, and a cap on public upload links.

## Stack and data

- pnpm workspaces, Node.js, TypeScript, React, and Vite.
- API: Express 5.
- Main application data: PostgreSQL through Prisma (`artifacts/api-server/prisma/schema.prisma`).
- API contract: `lib/api-spec/openapi.yaml`; generated React Query clients and Zod schemas live under `lib/api-client-react` and `lib/api-zod`.
- `lib/db` is a separate shared Drizzle package in the workspace; the MPS API's current models are defined in Prisma.
- Uploaded media uses the API server's object-storage adapter; required storage configuration depends on the deployment environment.

## Source map

- `artifacts/mps-td`: main MPS — TD web application and its visual design system.
- `artifacts/api-server`: API, authentication, database schema, and demo data.
- `artifacts/mockup-sandbox`: isolated component preview environment.
- `lib/api-spec`: OpenAPI contract and Orval configuration.
- `lib/api-client-react`: generated React Query API hooks and shared request transport.
- `lib/api-zod`: generated Zod validators and TypeScript API types.
- `lib/db`: shared Drizzle database package; currently distinct from the MPS Prisma models.
- `scripts`: repository scripts, including the post-merge hook.
- `docs/PROJECT_STRUCTURE.md`: file-by-file and folder-by-folder repository guide.

## Data change note

The English-only cleanup removes the `AppTranslation` table from the Prisma model. Applying `db:push` drops that bilingual-label table and its stored label rows; the rest of the operational schema is retained.
