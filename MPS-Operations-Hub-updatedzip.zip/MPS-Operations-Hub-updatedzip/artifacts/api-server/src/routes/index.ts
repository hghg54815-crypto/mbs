import { Router, type IRouter } from "express";
import authRouter from "./auth";
import healthRouter from "./health";
import mpsRouter from "./mps";
import storageRouter from "./storage";

const router: IRouter = Router();

router.use(authRouter);
router.use(healthRouter);
router.use(mpsRouter);
router.use(storageRouter);

export default router;
