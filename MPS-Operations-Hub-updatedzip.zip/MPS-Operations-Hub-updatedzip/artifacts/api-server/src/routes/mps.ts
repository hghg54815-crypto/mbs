import type { Prisma } from "@prisma/client";
import {
  CreateEmployeeBody,
  CreateItemBody,
  CreateJobCardBody,
  CreateTransactionBody,
  GetEmployeeActiveJobsParams,
  GetMpsReportsQueryParams,
  ListItemsQueryParams,
  ListJobCardsQueryParams,
  ListMaintenanceRequestsQueryParams,
  ListRequestersQueryParams,
  LookupRequesterBody,
  RequestMpsUploadUrlBody,
  SubmitMaintenanceRequestBody,
  UpdateEmployeeBody,
  UpdateItemBody,
  UpdateJobCardBody,
  UpdateMaintenanceRequestBody,
} from "@workspace/api-zod";
import { Router, type IRouter, type Request, type Response } from "express";
import { prisma } from "../lib/prisma";
import { ObjectStorageService } from "../lib/objectStorage";
import { allRegionNames, getRequestEmployee, hashPassword } from "../lib/auth";

const router: IRouter = Router();
const objectStorage = new ObjectStorageService();

// Limits for the public maintenance-request form (no sign-in, no one-time code).
const PENDING_VERIFICATION_REQUEST_LIMIT = 3; // open requests per unverified email
const VERIFIED_REQUESTS_PER_HOUR = 10; // per verified email
const NEW_REQUESTERS_PER_HOUR = 20; // new unverified emails across the whole system
const PUBLIC_UPLOAD_WINDOW_MS = 10 * 60 * 1000;
const PUBLIC_UPLOADS_PER_WINDOW = 60;
let publicUploadWindowStart = 0;
let publicUploadCount = 0;

const PENDING_VERIFICATION = "Pending Verification";

type AppRole = "Admin" | "Supervisor" | "Storekeeper" | "Technician" | "Manager";
type EmployeeWithRegions = Prisma.EmployeeWhitelistGetPayload<{
  include: { regions: true };
}>;
type JobCardWithTechnicians = Prisma.JobCardGetPayload<{
  include: { technicians: true };
}>;
type Handler = (req: Request, res: Response) => Promise<void>;

class HttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

function endpoint(handler: Handler) {
  return async (req: Request, res: Response) => {
    try {
      await handler(req, res);
    } catch (error) {
      if (error instanceof HttpError) {
        res.status(error.status).json({ error: error.message });
        return;
      }
      req.log.error({ err: error }, "MPS API request failed");
      res.status(500).json({ error: "Unable to complete this request" });
    }
  };
}

function normalizeEmail(value: string) {
  return value.trim().toLowerCase();
}

function isUniqueViolation(error: unknown) {
  return (
    typeof error === "object" &&
    error !== null &&
    (error as { code?: unknown }).code === "P2002"
  );
}

function routeParam(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] ?? "" : value ?? "";
}

function employeeRegions(employee: EmployeeWithRegions) {
  const regions = employee.regions.map((entry) => entry.region);
  return regions.length ? regions : [employee.region];
}

async function requireEmployee(
  req: Request,
  res: Response,
  roles?: AppRole[],
): Promise<NonNullable<EmployeeWithRegions> | null> {
  const employee = await getRequestEmployee(req);
  if (!employee) {
    res.status(401).json({ error: "Sign in to continue" });
    return null;
  }
  if (roles && !roles.includes(employee.role as AppRole)) {
    res.status(403).json({ error: "This action is not available for your role" });
    return null;
  }
  return employee;
}

function mapEmployee(employee: NonNullable<EmployeeWithRegions>) {
  return {
    employeeId: employee.employeeId,
    fullName: employee.fullName,
    email: employee.email,
    department: employee.department,
    region: employee.region,
    role: employee.role,
    regions: employeeRegions(employee),
  };
}

function stockForRegion(
  transactions: Array<{
    transactionType: string;
    quantity: number;
    region: string;
    toRegion: string | null;
  }>,
  region?: string,
) {
  return transactions.reduce((balance, transaction) => {
    if (transaction.transactionType === "IN") {
      return balance + (region && transaction.region !== region ? 0 : transaction.quantity);
    }
    if (transaction.transactionType === "OUT") {
      return balance - (region && transaction.region !== region ? 0 : transaction.quantity);
    }
    if (transaction.transactionType === "TRANSFER") {
      const outgoing =
        !region || transaction.region === region ? -transaction.quantity : 0;
      const incoming =
        !region || transaction.toRegion === region ? transaction.quantity : 0;
      return balance + outgoing + incoming;
    }
    return balance;
  }, 0);
}

function mapItem(
  item: {
    itemCode: string;
    itemName: string;
    description: string | null;
    unitOfMeasure: string;
    minStockLevel: number;
    binLocation: string | null;
    barcode: string | null;
    unitCost: number;
    transactions?: Array<{
      transactionType: string;
      quantity: number;
      region: string;
      toRegion: string | null;
      referenceNo: string | null;
      supplierName: string | null;
      purchaseType: string | null;
      invoiceDate: Date | null;
      unitCostAtTransaction: number;
      createdAt: Date;
    }>;
  },
  region?: string,
) {
  const transactions = item.transactions ?? [];
  const currentStock = stockForRegion(transactions, region);
  const purchaseHistory = transactions
    .filter(
      (transaction) =>
        transaction.transactionType === "IN" &&
        transaction.purchaseType !== "Return",
    )
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
    .slice(0, 8)
    .map((transaction) => ({
      date: (transaction.invoiceDate ?? transaction.createdAt).toISOString(),
      quantity: transaction.quantity,
      referenceNo: transaction.referenceNo,
      supplierName: transaction.supplierName,
      purchaseType: transaction.purchaseType,
      unitCost: transaction.unitCostAtTransaction,
    }));
  return {
    itemCode: item.itemCode,
    itemName: item.itemName,
    description: item.description,
    unitOfMeasure: item.unitOfMeasure,
    minStockLevel: item.minStockLevel,
    currentStock,
    unitCost: item.unitCost,
    valueSar: Math.max(currentStock, 0) * item.unitCost,
    binLocation: item.binLocation,
    barcode: item.barcode,
    purchaseHistory,
  };
}

function mapRequest(
  request: {
    requestId: string;
    employeeId: string;
    department: string;
    region: string;
    locationName: string;
    description: string;
    status: string;
    createdAt: Date;
    employee: { fullName: string };
    jobCards: Array<{ jobCardId: string }>;
    attachments: Array<{ path: string; name: string; type: string }>;
  },
) {
  return {
    requestId: request.requestId,
    employeeId: request.employeeId,
    employeeName: request.employee.fullName,
    department: request.department,
    region: request.region,
    locationName: request.locationName,
    description: request.description,
    status: request.status,
    createdAt: request.createdAt.toISOString(),
    jobCardIds: request.jobCards.map((job) => job.jobCardId),
    attachments: request.attachments.map(({ path, name, type }) => ({
      path,
      name,
      type,
    })),
  };
}

function mapJobCard(
  job: {
    jobCardId: string;
    requestId: string;
    teamName: string;
    supervisorId: string;
    region: string;
    jobStatus: string;
    repairReport: string | null;
    createdAt: Date;
    closedAt: Date | null;
    request: {
      locationName: string;
      description: string;
      employee: { email: string };
    };
    supervisor: { fullName: string };
    technicians: Array<{ employeeId: string; employee: { fullName: string } }>;
    media: Array<{ path: string; name: string; type: string }>;
  },
) {
  return {
    jobCardId: job.jobCardId,
    requestId: job.requestId,
    teamName: job.teamName,
    supervisorId: job.supervisorId,
    supervisorName: job.supervisor.fullName,
    region: job.region,
    jobStatus: job.jobStatus,
    technicianIds: job.technicians.map((tech) => tech.employeeId),
    technicianNames: job.technicians.map((tech) => tech.employee.fullName),
    repairReport: job.repairReport,
    createdAt: job.createdAt.toISOString(),
    closedAt: job.closedAt?.toISOString() ?? null,
    requestorEmail: job.request.employee.email,
    locationName: job.request.locationName,
    description: job.request.description,
    attachments: job.media.map(({ path, name, type }) => ({ path, name, type })),
  };
}

function mapTransaction(
  transaction: {
    transactionId: number;
    transactionType: string;
    itemCode: string;
    quantity: number;
    employeeId: string;
    employeeNameSnapshot: string;
    jobCardId: string | null;
    referenceNo: string | null;
    supplierName: string | null;
    purchaseType: string | null;
    invoiceDate: Date | null;
    unitCostAtTransaction: number;
    region: string;
    toRegion: string | null;
    createdAt: Date;
    item: { itemName: string };
  },
) {
  return {
    transactionId: transaction.transactionId,
    transactionType: transaction.transactionType,
    itemCode: transaction.itemCode,
    itemName: transaction.item.itemName,
    quantity: transaction.quantity,
    employeeId: transaction.employeeId,
    employeeName: transaction.employeeNameSnapshot,
    jobCardId: transaction.jobCardId,
    referenceNo: transaction.referenceNo,
    supplierName: transaction.supplierName,
    purchaseType: transaction.purchaseType,
    invoiceDate: transaction.invoiceDate?.toISOString() ?? null,
    unitCost: transaction.unitCostAtTransaction,
    region: transaction.region,
    toRegion: transaction.toRegion,
    createdAt: transaction.createdAt.toISOString(),
  };
}

async function nextSequence(tx: Prisma.TransactionClient, key: string) {
  const row = await tx.idSequence.upsert({
    where: { key },
    create: { key, value: 1 },
    update: { value: { increment: 1 } },
  });
  return row.value;
}

/**
 * Requests sent by a not-yet-verified requester wait with the status
 * "Pending Verification". Once the requester is verified they become normal
 * "Pending" requests, and any new location they typed is queued for review.
 */
async function releasePendingVerificationRequests(
  tx: Prisma.TransactionClient,
  employeeId: string,
) {
  const waiting = await tx.maintenanceRequest.findMany({
    where: { employeeId, status: PENDING_VERIFICATION },
  });
  if (!waiting.length) return 0;
  await tx.maintenanceRequest.updateMany({
    where: { employeeId, status: PENDING_VERIFICATION },
    data: { status: "Pending" },
  });
  for (const request of waiting.filter((entry) => entry.isCustomLocation)) {
    await tx.locationOption.upsert({
      where: {
        name_region: { name: request.locationName, region: request.region },
      },
      create: {
        name: request.locationName,
        region: request.region,
        status: "Pending Review",
      },
      update: {},
    });
  }
  return waiting.length;
}

function mapRequester(
  person: {
    employeeId: string;
    fullName: string;
    email: string;
    department: string;
    region: string;
    verificationStatus: string;
    createdAt: Date;
    verifiedAt: Date | null;
    requests: Array<{
      requestId: string;
      status: string;
      description: string;
      locationName: string;
      createdAt: Date;
    }>;
  },
) {
  const waiting = person.requests.filter((request) => request.status === PENDING_VERIFICATION);
  const latest = [...person.requests].sort(
    (a, b) => b.createdAt.getTime() - a.createdAt.getTime(),
  )[0];
  return {
    employeeId: person.employeeId,
    fullName: person.fullName,
    email: person.email,
    department: person.department,
    region: person.region,
    verificationStatus: person.verificationStatus,
    createdAt: person.createdAt.toISOString(),
    verifiedAt: person.verifiedAt?.toISOString() ?? null,
    waitingRequests: waiting.length,
    latestRequestId: latest?.requestId ?? null,
    latestLocation: latest?.locationName ?? null,
    latestDescription: latest ? latest.description.slice(0, 160) : null,
  };
}

async function assertKnownRegion(region: string) {
  const regions = await allRegionNames();
  if (!regions.includes(region)) {
    throw new HttpError(400, "Choose one of the listed regions");
  }
}

function validateMedia(attachments: Array<{ path: string; name: string; type: string }>) {
  if (attachments.length > 3) {
    throw new HttpError(400, "Upload no more than two photos and one video");
  }
  const photos = attachments.filter((file) => file.type.startsWith("image/"));
  const videos = attachments.filter((file) => file.type.startsWith("video/"));
  if (
    photos.length > 2 ||
    videos.length > 1 ||
    photos.length + videos.length !== attachments.length
  ) {
    throw new HttpError(400, "Only two photos and one video are allowed");
  }
  if (
    photos.some((file) => !["image/jpeg", "image/png", "image/webp"].includes(file.type)) ||
    videos.some((file) => !["video/mp4", "video/webm"].includes(file.type))
  ) {
    throw new HttpError(400, "Unsupported photo or video file type");
  }
  if (attachments.some((file) => !file.path.startsWith("/objects/uploads/"))) {
    throw new HttpError(400, "Invalid uploaded file reference");
  }
}

async function accessibleRegion(
  employee: NonNullable<EmployeeWithRegions>,
  requested?: string,
) {
  const regions = employeeRegions(employee);
  if (requested && !regions.includes(requested)) {
    throw new HttpError(403, "You do not have access to that region");
  }
  return requested;
}

router.get(
  "/mps/me",
  endpoint(async (req, res) => {
    const employee = await requireEmployee(req, res);
    if (employee) res.json(mapEmployee(employee));
  }),
);

router.get(
  "/mps/dashboard",
  endpoint(async (req, res) => {
    const employee = await requireEmployee(req, res);
    if (!employee) return;
    const regions = employeeRegions(employee);
    const [requests, jobs, items] = await Promise.all([
      prisma.maintenanceRequest.findMany({
        where: { region: { in: regions }, status: { not: PENDING_VERIFICATION } },
        include: { employee: true, jobCards: true, attachments: true },
        orderBy: { createdAt: "desc" },
      }),
      prisma.jobCard.findMany({
        where:
          employee.role === "Technician"
            ? { technicians: { some: { employeeId: employee.employeeId } } }
            : { region: { in: regions } },
      }),
      prisma.itemMaster.findMany({ include: { transactions: true } }),
    ]);
    const mappedItems = items.map((item) => mapItem(item));
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0, 0, 0, 0);
    const jobStatusBreakdown = new Map<string, number>();
    for (const job of jobs) {
      jobStatusBreakdown.set(
        job.jobStatus,
        (jobStatusBreakdown.get(job.jobStatus) ?? 0) + 1,
      );
    }
    res.json({
      openRequests: requests.filter((request) => request.status === "Pending").length,
      activeJobs: jobs.filter(
        (job) => !["Completed / Closed", "Cancelled"].includes(job.jobStatus),
      ).length,
      pendingMaterial: jobs.filter((job) => job.jobStatus === "Pending Material").length,
      completedThisMonth: jobs.filter(
        (job) =>
          job.jobStatus === "Completed / Closed" &&
          job.closedAt &&
          job.closedAt >= startOfMonth,
      ).length,
      lowStockItems: mappedItems.filter(
        (item) => item.currentStock <= item.minStockLevel,
      ).length,
      stockValueSar: mappedItems.reduce((sum, item) => sum + item.valueSar, 0),
      recentRequests: requests.slice(0, 6).map(mapRequest),
      jobStatusBreakdown: Array.from(jobStatusBreakdown, ([status, count]) => ({
        status,
        count,
      })),
    });
  }),
);

router.get(
  "/mps/items",
  endpoint(async (req, res) => {
    const employee = await requireEmployee(req, res);
    if (!employee) return;
    const parsed = ListItemsQueryParams.safeParse(req.query);
    if (!parsed.success) throw new HttpError(400, "Invalid inventory filter");
    const region = await accessibleRegion(employee, parsed.data.region);
    const items = await prisma.itemMaster.findMany({
      include: { transactions: true },
      orderBy: { itemName: "asc" },
    });
    res.json(items.map((item) => mapItem(item, region)));
  }),
);

router.post(
  "/mps/items",
  endpoint(async (req, res) => {
    const employee = await requireEmployee(req, res, ["Admin", "Storekeeper"]);
    if (!employee) return;
    const parsed = CreateItemBody.safeParse(req.body);
    if (!parsed.success) throw new HttpError(400, "Enter valid item details");
    const item = await prisma.itemMaster.create({
      data: {
        ...parsed.data,
        unitCost: parsed.data.unitCost ?? 0,
        description: parsed.data.description || null,
        binLocation: parsed.data.binLocation || null,
        barcode: parsed.data.barcode || null,
      },
      include: { transactions: true },
    });
    res.status(201).json(mapItem(item));
  }),
);

router.patch(
  "/mps/items/:itemCode",
  endpoint(async (req, res) => {
    const employee = await requireEmployee(req, res, ["Admin", "Storekeeper"]);
    if (!employee) return;
    const parsed = UpdateItemBody.safeParse(req.body);
    if (!parsed.success) throw new HttpError(400, "Enter valid item details");
    const item = await prisma.itemMaster.update({
      where: { itemCode: routeParam(req.params.itemCode) },
      data: {
        ...parsed.data,
        description: parsed.data.description || null,
        binLocation: parsed.data.binLocation || null,
        barcode: parsed.data.barcode || null,
      },
      include: { transactions: true },
    });
    res.json(mapItem(item));
  }),
);

router.get(
  "/mps/transactions",
  endpoint(async (req, res) => {
    const employee = await requireEmployee(req, res);
    if (!employee) return;
    const region = typeof req.query.region === "string" ? req.query.region : undefined;
    await accessibleRegion(employee, region);
    const type = typeof req.query.type === "string" ? req.query.type : undefined;
    if (type && !["IN", "OUT", "TRANSFER"].includes(type)) {
      throw new HttpError(400, "Invalid transaction type");
    }
    const transactions = await prisma.warehouseTransaction.findMany({
      where: {
        ...(region
          ? { OR: [{ region }, { toRegion: region }] }
          : {
              OR: [
                { region: { in: employeeRegions(employee) } },
                { toRegion: { in: employeeRegions(employee) } },
              ],
            }),
        ...(type ? { transactionType: type } : {}),
      },
      include: { item: true },
      orderBy: { createdAt: "desc" },
      take: 500,
    });
    res.json(transactions.map(mapTransaction));
  }),
);

router.post(
  "/mps/transactions",
  endpoint(async (req, res) => {
    const recorder = await requireEmployee(req, res, ["Admin", "Storekeeper"]);
    if (!recorder) return;
    const parsed = CreateTransactionBody.safeParse(req.body);
    if (!parsed.success) throw new HttpError(400, "Enter valid transaction details");
    const input = parsed.data;
    // The warehouse that records the movement (the source warehouse for transfers).
    await accessibleRegion(recorder, input.region);

    const item = await prisma.itemMaster.findUnique({
      where: { itemCode: input.itemCode },
    });
    if (!item) throw new HttpError(404, "Inventory item not found");

    let transactionEmployee: NonNullable<EmployeeWithRegions> = recorder;
    let jobCardId: string | null = null;
    let referenceNo: string | null = input.referenceNo?.trim() || null;
    let toRegion: string | null = null;
    let consumesStock = false;

    if (input.transactionType === "OUT") {
      // Issue: materials leave the warehouse for a technician on an active job card.
      if (!input.jobCardId) throw new HttpError(400, "Select a job card for maintenance issue");
      const selectedEmployee = await prisma.employeeWhitelist.findUnique({
        where: { employeeId: input.employeeId },
        include: { regions: true },
      });
      if (!selectedEmployee) throw new HttpError(404, "Employee ID not found");
      const jobCard = await prisma.jobCard.findUnique({
        where: { jobCardId: input.jobCardId },
        include: { technicians: true },
      });
      if (!jobCard || !jobCard.technicians.some((tech) => tech.employeeId === input.employeeId)) {
        throw new HttpError(400, "The selected employee is not assigned to this job card");
      }
      if (jobCard.region !== input.region) throw new HttpError(400, "Job card region does not match");
      transactionEmployee = selectedEmployee;
      jobCardId = jobCard.jobCardId;
      consumesStock = true;
    } else if (input.transactionType === "IN" && input.purchaseType === "Return") {
      // Return: a technician gives unused materials back to the warehouse.
      const selectedEmployee = await prisma.employeeWhitelist.findUnique({
        where: { employeeId: input.employeeId },
        include: { regions: true },
      });
      if (!selectedEmployee) throw new HttpError(404, "Employee ID not found");
      if (input.jobCardId) {
        const jobCard = await prisma.jobCard.findUnique({
          where: { jobCardId: input.jobCardId },
        });
        if (!jobCard) throw new HttpError(404, "Job card not found");
        if (jobCard.region !== input.region) throw new HttpError(400, "Job card region does not match");
        jobCardId = jobCard.jobCardId;
      }
      referenceNo = referenceNo ?? jobCardId;
      if (!referenceNo) throw new HttpError(400, "A job card or return reference is required");
      transactionEmployee = selectedEmployee;
    } else if (input.transactionType === "IN") {
      // Receipt: new stock arrives from a supplier.
      if (
        !["PO", "Cash"].includes(input.purchaseType ?? "") ||
        !referenceNo ||
        !input.supplierName?.trim()
      ) {
        throw new HttpError(400, "Purchase receipt requires PO/Cash type, invoice number and supplier");
      }
    } else {
      // Transfer: stock moves from this warehouse (region) to another one.
      if (!input.toRegion) throw new HttpError(400, "Choose the destination warehouse");
      if (input.toRegion === input.region) {
        throw new HttpError(400, "Choose a different transfer destination region");
      }
      await assertKnownRegion(input.toRegion);
      toRegion = input.toRegion;
      consumesStock = true;
    }

    const cost = input.unitCost ?? item.unitCost;
    const transaction = await prisma.$transaction(async (tx) => {
      if (consumesStock) {
        const movements = await tx.warehouseTransaction.findMany({
          where: { itemCode: item.itemCode },
          select: { transactionType: true, quantity: true, region: true, toRegion: true },
        });
        const available = stockForRegion(movements, input.region);
        if (available < input.quantity) {
          throw new HttpError(
            409,
            `Insufficient stock in ${input.region}: ${available} available, ${input.quantity} requested`,
          );
        }
      }
      if (input.transactionType === "IN" && input.purchaseType !== "Return" && cost > 0) {
        await tx.itemMaster.update({
          where: { itemCode: item.itemCode },
          data: { unitCost: cost },
        });
      }
      return tx.warehouseTransaction.create({
        data: {
          transactionType: input.transactionType,
          itemCode: item.itemCode,
          quantity: input.quantity,
          employeeId: transactionEmployee.employeeId,
          employeeNameSnapshot: transactionEmployee.fullName,
          recordedById: recorder.employeeId,
          jobCardId,
          referenceNo,
          supplierName: input.supplierName?.trim() || null,
          purchaseType: input.transactionType === "IN" ? input.purchaseType || null : null,
          invoiceDate: input.invoiceDate ? new Date(input.invoiceDate) : null,
          region: input.region,
          toRegion,
          unitCostAtTransaction: cost,
        },
        include: { item: true },
      });
    });
    res.status(201).json(mapTransaction(transaction));
  }),
);

router.get(
  "/mps/regions",
  endpoint(async (req, res) => {
    const employee = await requireEmployee(req, res);
    if (!employee) return;
    res.json(await allRegionNames());
  }),
);

router.get(
  "/mps/employees",
  endpoint(async (req, res) => {
    const employee = await requireEmployee(req, res, [
      "Admin",
      "Supervisor",
      "Storekeeper",
      "Manager",
    ]);
    if (!employee) return;
    // People who only send maintenance requests ("Requester") are not team members.
    const employees = await prisma.employeeWhitelist.findMany({
      where: { role: { not: "Requester" } },
      include: { regions: true },
      orderBy: { fullName: "asc" },
    });
    res.json(employees.map(mapEmployee));
  }),
);

function regionSet(primary: string, extra: string[] | undefined) {
  return Array.from(
    new Set([primary, ...(extra ?? [])].map((region) => region.trim()).filter(Boolean)),
  );
}

async function otherAdminExists(excludingEmployeeId: string) {
  const count = await prisma.employeeWhitelist.count({
    where: { role: "Admin", employeeId: { not: excludingEmployeeId } },
  });
  return count > 0;
}

router.post(
  "/mps/employees",
  endpoint(async (req, res) => {
    const admin = await requireEmployee(req, res, ["Admin"]);
    if (!admin) return;
    const parsed = CreateEmployeeBody.safeParse(req.body);
    if (!parsed.success) throw new HttpError(400, "Enter valid employee details");
    const { regions, temporaryPassword, ...data } = parsed.data;
    const employeeId = data.employeeId.trim();
    const email = normalizeEmail(data.email);

    const [sameId, sameEmail] = await Promise.all([
      prisma.employeeWhitelist.findUnique({ where: { employeeId } }),
      prisma.employeeWhitelist.findUnique({ where: { email } }),
    ]);
    if (sameId) {
      throw new HttpError(
        409,
        `Duplicate employee: ID ${employeeId} already belongs to ${sameId.fullName}. Edit that employee instead.`,
      );
    }
    if (sameEmail && sameEmail.role !== "Requester") {
      throw new HttpError(
        409,
        `Duplicate employee: ${email} is already registered to ${sameEmail.fullName} (${sameEmail.employeeId}).`,
      );
    }

    const passwordHash = await hashPassword(temporaryPassword);
    const regionList = regionSet(data.region, data.role === "Manager" ? undefined : regions);
    const created = await prisma
      .$transaction(async (tx) => {
        if (sameEmail) {
          // This email already sent maintenance requests as a requester: free the email,
          // create the team account, then move the requests over to it.
          await tx.employeeWhitelist.update({
            where: { employeeId: sameEmail.employeeId },
            data: { email: `replaced+${sameEmail.employeeId.toLowerCase()}@invalid.local` },
          });
        }
        const row = await tx.employeeWhitelist.create({
          data: {
            ...data,
            employeeId,
            email,
            passwordHash,
            mustChangePassword: true,
            verificationStatus: "Verified",
            verifiedAt: new Date(),
            verifiedById: admin.employeeId,
          },
        });
        if (sameEmail) {
          await tx.maintenanceRequest.updateMany({
            where: { employeeId: sameEmail.employeeId },
            data: { employeeId: row.employeeId },
          });
          await releasePendingVerificationRequests(tx, row.employeeId);
          await tx.employeeWhitelist.delete({ where: { employeeId: sameEmail.employeeId } });
        }
        await tx.employeeRegion.createMany({
          data: regionList.map((region) => ({ employeeId: row.employeeId, region })),
          skipDuplicates: true,
        });
        return tx.employeeWhitelist.findUniqueOrThrow({
          where: { employeeId: row.employeeId },
          include: { regions: true },
        });
      })
      .catch((error: unknown) => {
        if (isUniqueViolation(error)) {
          throw new HttpError(409, "Duplicate employee: this ID or email already exists.");
        }
        throw error;
      });
    res.status(201).json(mapEmployee(created));
  }),
);

router.patch(
  "/mps/employees/:employeeId",
  endpoint(async (req, res) => {
    const admin = await requireEmployee(req, res, ["Admin"]);
    if (!admin) return;
    const parsed = UpdateEmployeeBody.safeParse(req.body);
    if (!parsed.success) throw new HttpError(400, "Enter valid employee details");
    const employeeId = routeParam(req.params.employeeId);
    const existing = await prisma.employeeWhitelist.findUnique({
      where: { employeeId },
      include: { regions: true },
    });
    if (!existing || existing.role === "Requester") {
      throw new HttpError(404, "Employee not found");
    }
    const updates = parsed.data;
    const isSelf = existing.employeeId === admin.employeeId;

    let email: string | undefined;
    if (updates.email !== undefined) {
      email = normalizeEmail(updates.email);
      const holder = await prisma.employeeWhitelist.findUnique({ where: { email } });
      if (holder && holder.employeeId !== existing.employeeId) {
        throw new HttpError(
          409,
          `Duplicate employee: ${email} is already registered to ${holder.fullName} (${holder.employeeId}).`,
        );
      }
    }
    if (updates.role !== undefined && updates.role !== existing.role) {
      if (isSelf) throw new HttpError(400, "You cannot change your own role");
      if (existing.role === "Admin" && !(await otherAdminExists(existing.employeeId))) {
        throw new HttpError(400, "At least one Admin account must remain");
      }
    }
    if (updates.temporaryPassword !== undefined && isSelf) {
      throw new HttpError(400, "Use Change password to update your own password");
    }

    const role = updates.role ?? existing.role;
    const primaryRegion = updates.region ?? existing.region;
    const storedExtras = existing.regions
      .map((entry) => entry.region)
      .filter((region) => region !== existing.region);
    const regionList =
      role === "Manager"
        ? [primaryRegion]
        : regionSet(primaryRegion, updates.regions ?? storedExtras);
    const regionsChanged =
      updates.regions !== undefined ||
      updates.region !== undefined ||
      updates.role !== undefined;
    const passwordHash =
      updates.temporaryPassword !== undefined
        ? await hashPassword(updates.temporaryPassword)
        : undefined;

    const updated = await prisma.$transaction(async (tx) => {
      await tx.employeeWhitelist.update({
        where: { employeeId: existing.employeeId },
        data: {
          ...(updates.fullName !== undefined ? { fullName: updates.fullName } : {}),
          ...(email !== undefined ? { email } : {}),
          ...(updates.department !== undefined ? { department: updates.department } : {}),
          ...(updates.region !== undefined ? { region: updates.region } : {}),
          ...(updates.role !== undefined ? { role: updates.role } : {}),
          ...(passwordHash !== undefined ? { passwordHash, mustChangePassword: true } : {}),
        },
      });
      if (passwordHash !== undefined) {
        // A reset must also end every sign-in the old password created.
        await tx.authSession.deleteMany({ where: { employeeId: existing.employeeId } });
      }
      if (regionsChanged) {
        await tx.employeeRegion.deleteMany({ where: { employeeId: existing.employeeId } });
        await tx.employeeRegion.createMany({
          data: regionList.map((region) => ({ employeeId: existing.employeeId, region })),
          skipDuplicates: true,
        });
      }
      return tx.employeeWhitelist.findUniqueOrThrow({
        where: { employeeId: existing.employeeId },
        include: { regions: true },
      });
    });
    res.json(mapEmployee(updated));
  }),
);

router.delete(
  "/mps/employees/:employeeId",
  endpoint(async (req, res) => {
    const admin = await requireEmployee(req, res, ["Admin"]);
    if (!admin) return;
    const employeeId = routeParam(req.params.employeeId);
    const existing = await prisma.employeeWhitelist.findUnique({ where: { employeeId } });
    if (!existing || existing.role === "Requester") {
      throw new HttpError(404, "Employee not found");
    }
    if (existing.employeeId === admin.employeeId) {
      throw new HttpError(400, "You cannot delete your own account");
    }
    if (existing.role === "Admin" && !(await otherAdminExists(existing.employeeId))) {
      throw new HttpError(400, "At least one Admin account must remain");
    }
    const [requests, supervised, assigned, transactions, recorded] = await Promise.all([
      prisma.maintenanceRequest.count({ where: { employeeId } }),
      prisma.jobCard.count({ where: { supervisorId: employeeId } }),
      prisma.jobCardTechnician.count({ where: { employeeId } }),
      prisma.warehouseTransaction.count({ where: { employeeId } }),
      prisma.warehouseTransaction.count({ where: { recordedById: employeeId } }),
    ]);
    const linked = requests + supervised + assigned + transactions + recorded;
    if (linked > 0) {
      throw new HttpError(
        409,
        `${existing.fullName} has ${linked} linked records (requests, job cards or stock movements) and cannot be deleted. Reset their password or change their role instead.`,
      );
    }
    await prisma.employeeWhitelist.delete({ where: { employeeId } });
    res.status(204).end();
  }),
);

router.get(
  "/mps/requesters",
  endpoint(async (req, res) => {
    const admin = await requireEmployee(req, res, ["Admin"]);
    if (!admin) return;
    const parsed = ListRequestersQueryParams.safeParse(req.query);
    if (!parsed.success) throw new HttpError(400, "Invalid requester filter");
    const people = await prisma.employeeWhitelist.findMany({
      where: {
        role: "Requester",
        ...(parsed.data.status ? { verificationStatus: parsed.data.status } : {}),
      },
      include: { requests: true },
      orderBy: { createdAt: "desc" },
      take: 500,
    });
    res.json(people.map(mapRequester));
  }),
);

router.post(
  "/mps/requesters/:employeeId/verify",
  endpoint(async (req, res) => {
    const admin = await requireEmployee(req, res, ["Admin"]);
    if (!admin) return;
    const employeeId = routeParam(req.params.employeeId);
    const person = await prisma.employeeWhitelist.findUnique({ where: { employeeId } });
    if (!person || person.role !== "Requester") throw new HttpError(404, "Requester not found");
    const updated = await prisma.$transaction(async (tx) => {
      await tx.employeeWhitelist.update({
        where: { employeeId },
        data: {
          verificationStatus: "Verified",
          verifiedAt: new Date(),
          verifiedById: admin.employeeId,
        },
      });
      await releasePendingVerificationRequests(tx, employeeId);
      return tx.employeeWhitelist.findUniqueOrThrow({
        where: { employeeId },
        include: { requests: true },
      });
    });
    res.json(mapRequester(updated));
  }),
);

router.post(
  "/mps/requesters/:employeeId/reject",
  endpoint(async (req, res) => {
    const admin = await requireEmployee(req, res, ["Admin"]);
    if (!admin) return;
    const employeeId = routeParam(req.params.employeeId);
    const person = await prisma.employeeWhitelist.findUnique({ where: { employeeId } });
    if (!person || person.role !== "Requester") throw new HttpError(404, "Requester not found");
    const updated = await prisma.$transaction(async (tx) => {
      await tx.employeeWhitelist.update({
        where: { employeeId },
        data: {
          verificationStatus: "Rejected",
          verifiedAt: null,
          verifiedById: admin.employeeId,
        },
      });
      await tx.maintenanceRequest.updateMany({
        where: { employeeId, status: PENDING_VERIFICATION },
        data: { status: "Rejected" },
      });
      return tx.employeeWhitelist.findUniqueOrThrow({
        where: { employeeId },
        include: { requests: true },
      });
    });
    res.json(mapRequester(updated));
  }),
);

router.get(
  "/mps/employees/:employeeId/active-jobs",
  endpoint(async (req, res) => {
    const current = await requireEmployee(req, res);
    if (!current) return;
    const parsed = GetEmployeeActiveJobsParams.safeParse({
      employeeId: routeParam(req.params.employeeId),
    });
    if (!parsed.success) throw new HttpError(400, "Enter a valid employee ID");
    if (
      current.role === "Technician" &&
      current.employeeId !== parsed.data.employeeId
    ) {
      throw new HttpError(403, "You can only view your own assigned work");
    }
    if (!["Admin", "Supervisor", "Storekeeper", "Technician"].includes(current.role)) {
      throw new HttpError(403, "This action is not available for your role");
    }
    const jobs = await prisma.jobCard.findMany({
      where: {
        technicians: { some: { employeeId: parsed.data.employeeId } },
        jobStatus: { notIn: ["Completed / Closed", "Cancelled"] },
        region: { in: employeeRegions(current) },
      },
      include: { request: { select: { locationName: true } } },
      orderBy: { createdAt: "desc" },
    });
    res.json(
      jobs.map((job) => ({
        jobCardId: job.jobCardId,
        requestId: job.requestId,
        teamName: job.teamName,
        jobStatus: job.jobStatus,
        locationName: job.request.locationName,
        createdAt: job.createdAt.toISOString(),
      })),
    );
  }),
);

router.get(
  "/mps/requests",
  endpoint(async (req, res) => {
    const employee = await requireEmployee(req, res, [
      "Admin",
      "Supervisor",
      "Storekeeper",
      "Manager",
    ]);
    if (!employee) return;
    const parsed = ListMaintenanceRequestsQueryParams.safeParse(req.query);
    if (!parsed.success) throw new HttpError(400, "Invalid request filter");
    const region = await accessibleRegion(employee, parsed.data.region);
    const canSeeUnverified = employee.role === "Admin";
    if (parsed.data.status === PENDING_VERIFICATION && !canSeeUnverified) {
      res.json([]);
      return;
    }
    const requests = await prisma.maintenanceRequest.findMany({
      where: {
        region: region ? region : { in: employeeRegions(employee) },
        ...(parsed.data.status
          ? { status: parsed.data.status }
          : canSeeUnverified
            ? {}
            : { status: { not: PENDING_VERIFICATION } }),
      },
      include: { employee: true, jobCards: true, attachments: true },
      orderBy: { createdAt: "desc" },
    });
    res.json(requests.map(mapRequest));
  }),
);

router.post(
  "/mps/requests/lookup",
  endpoint(async (req, res) => {
    const parsed = LookupRequesterBody.safeParse(req.body);
    if (!parsed.success) throw new HttpError(400, "Enter a valid email address");
    const person = await prisma.employeeWhitelist.findUnique({
      where: { email: normalizeEmail(parsed.data.email) },
      select: { verificationStatus: true },
    });
    // Only the status is returned: the form uses it to decide what to ask next.
    res.json({ status: person ? person.verificationStatus : "New" });
  }),
);

router.post(
  "/mps/requests",
  endpoint(async (req, res) => {
    const parsed = SubmitMaintenanceRequestBody.safeParse(req.body);
    if (!parsed.success) throw new HttpError(400, "Complete all required request fields");
    const input = parsed.data;
    const email = normalizeEmail(input.email);
    const attachments = input.attachments ?? [];
    validateMedia(attachments);
    await assertKnownRegion(input.region);

    const person = await prisma.employeeWhitelist.findUnique({ where: { email } });
    const hourAgo = new Date(Date.now() - 60 * 60 * 1000);
    const fullName = input.fullName?.trim() ?? "";

    if (!person) {
      if (fullName.length < 2) throw new HttpError(400, "Enter your full name");
      const newToday = await prisma.employeeWhitelist.count({
        where: { role: "Requester", createdAt: { gte: hourAgo } },
      });
      if (newToday >= NEW_REQUESTERS_PER_HOUR) {
        throw new HttpError(429, "Too many new registrations right now. Please try again later.");
      }
    } else if (person.verificationStatus === "Rejected") {
      throw new HttpError(
        403,
        "This email was not approved to send maintenance requests. Contact your administrator.",
      );
    } else if (person.verificationStatus === "Pending") {
      const waiting = await prisma.maintenanceRequest.count({
        where: { employeeId: person.employeeId, status: PENDING_VERIFICATION },
      });
      if (waiting >= PENDING_VERIFICATION_REQUEST_LIMIT) {
        throw new HttpError(
          429,
          "Your email is still awaiting verification. Please wait for approval before sending more requests.",
        );
      }
    } else {
      const recent = await prisma.maintenanceRequest.count({
        where: { employeeId: person.employeeId, createdAt: { gte: hourAgo } },
      });
      if (recent >= VERIFIED_REQUESTS_PER_HOUR) {
        throw new HttpError(429, "Too many requests in the last hour. Please try again later.");
      }
    }

    const verified = person?.verificationStatus === "Verified";
    const location = await prisma.locationOption.findUnique({
      where: {
        name_region: { name: input.locationName, region: input.region },
      },
    });
    const isCustom = Boolean(input.isCustomLocation) || !location;

    const request = await prisma
      .$transaction(async (tx) => {
        let requester = person;
        if (!requester) {
          const sequence = await nextSequence(tx, "requester");
          requester = await tx.employeeWhitelist.create({
            data: {
              employeeId: `REQR-${sequence.toString().padStart(5, "0")}`,
              fullName,
              email,
              department: input.department,
              region: input.region,
              role: "Requester",
              verificationStatus: "Pending",
            },
          });
        }
        const requestSequence = await nextSequence(
          tx,
          `request:${new Date().getFullYear()}`,
        );
        const requestId = `REQ-${new Date().getFullYear()}-${requestSequence
          .toString()
          .padStart(4, "0")}`;
        const created = await tx.maintenanceRequest.create({
          data: {
            requestId,
            employeeId: requester.employeeId,
            department: input.department,
            region: input.region,
            locationName: input.locationName,
            description: input.description,
            status: verified ? "Pending" : PENDING_VERIFICATION,
            isCustomLocation: isCustom,
            attachments: {
              create: attachments.map((file) => ({
                path: file.path,
                name: file.name,
                type: file.type,
              })),
            },
          },
          include: { employee: true, jobCards: true, attachments: true },
        });
        // Unlisted locations are only queued for review once the requester is verified,
        // so anonymous visitors cannot add entries to the shared location list.
        if (isCustom && verified) {
          await tx.locationOption.upsert({
            where: {
              name_region: { name: input.locationName, region: input.region },
            },
            create: {
              name: input.locationName,
              region: input.region,
              status: "Pending Review",
            },
            update: { status: "Pending Review" },
          });
        }
        return created;
      })
      .catch((error: unknown) => {
        if (isUniqueViolation(error)) {
          throw new HttpError(409, "Your registration is being processed. Please submit again.");
        }
        throw error;
      });
    res.status(201).json(mapRequest(request));
  }),
);

router.patch(
  "/mps/requests/:requestId",
  endpoint(async (req, res) => {
    const employee = await requireEmployee(req, res, ["Admin", "Supervisor"]);
    if (!employee) return;
    const parsed = UpdateMaintenanceRequestBody.safeParse(req.body);
    if (!parsed.success) throw new HttpError(400, "Choose an approved request status");
    const existing = await prisma.maintenanceRequest.findUnique({
      where: { requestId: routeParam(req.params.requestId) },
    });
    if (!existing) throw new HttpError(404, "Maintenance request not found");
    await accessibleRegion(employee, existing.region);
    if (existing.status === PENDING_VERIFICATION) {
      throw new HttpError(409, "Verify the requester's email before reviewing this request");
    }
    const request = await prisma.maintenanceRequest.update({
      where: { requestId: existing.requestId },
      data: { status: parsed.data.status },
      include: { employee: true, jobCards: true, attachments: true },
    });
    res.json(mapRequest(request));
  }),
);

router.get(
  "/mps/job-cards",
  endpoint(async (req, res) => {
    const employee = await requireEmployee(req, res);
    if (!employee) return;
    const parsed = ListJobCardsQueryParams.safeParse(req.query);
    if (!parsed.success) throw new HttpError(400, "Invalid job-card filter");
    const region = await accessibleRegion(employee, parsed.data.region);
    const jobs = await prisma.jobCard.findMany({
      where: {
        ...(employee.role === "Technician"
          ? { technicians: { some: { employeeId: employee.employeeId } } }
          : { region: region ? region : { in: employeeRegions(employee) } }),
        ...(parsed.data.status ? { jobStatus: parsed.data.status } : {}),
      },
      include: {
        request: { include: { employee: true } },
        supervisor: true,
        technicians: { include: { employee: true } },
        media: true,
      },
      orderBy: { createdAt: "desc" },
    });
    res.json(jobs.map(mapJobCard));
  }),
);

router.post(
  "/mps/job-cards",
  endpoint(async (req, res) => {
    const supervisor = await requireEmployee(req, res, ["Supervisor"]);
    if (!supervisor) return;
    const parsed = CreateJobCardBody.safeParse(req.body);
    if (!parsed.success) throw new HttpError(400, "Enter valid job-card details");
    const request = await prisma.maintenanceRequest.findUnique({
      where: { requestId: parsed.data.requestId },
      include: { employee: true },
    });
    if (!request) throw new HttpError(404, "Maintenance request not found");
    await accessibleRegion(supervisor, request.region);
    if (request.status === "Rejected") {
      throw new HttpError(400, "Rejected requests cannot be assigned to a job card");
    }
    if (request.status === PENDING_VERIFICATION) {
      throw new HttpError(409, "The requester's email must be verified before assigning a job card");
    }
    const technicians = await prisma.employeeWhitelist.findMany({
      where: {
        employeeId: { in: parsed.data.technicianIds },
        role: "Technician",
      },
    });
    if (technicians.length !== parsed.data.technicianIds.length) {
      throw new HttpError(400, "Select valid technician employee IDs");
    }
    const year = new Date().getFullYear();
    const regionCode = request.region
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^A-Za-z0-9]+/g, "")
      .toUpperCase();
    const job = await prisma.$transaction(async (tx) => {
      const sequence = await nextSequence(
        tx,
        `jobcard:${regionCode}:${year}`,
      );
      const jobCardId = `${regionCode}-TEAM-${year}-${sequence
        .toString()
        .padStart(4, "0")}`;
      const created = await tx.jobCard.create({
        data: {
          jobCardId,
          requestId: request.requestId,
          teamName: parsed.data.teamName,
          supervisorId: supervisor.employeeId,
          region: request.region,
          technicians: {
            create: parsed.data.technicianIds.map((employeeId) => ({ employeeId })),
          },
        },
        include: {
          request: { include: { employee: true } },
          supervisor: true,
          technicians: { include: { employee: true } },
          media: true,
        },
      });
      await tx.maintenanceRequest.update({
        where: { requestId: request.requestId },
        data: { status: "Approved" },
      });
      return created;
    });
    res.status(201).json(mapJobCard(job));
  }),
);

router.patch(
  "/mps/job-cards/:jobCardId",
  endpoint(async (req, res) => {
    const supervisor = await requireEmployee(req, res, ["Supervisor"]);
    if (!supervisor) return;
    const parsed = UpdateJobCardBody.safeParse(req.body);
    if (!parsed.success) throw new HttpError(400, "Enter valid job-card updates");
    const existing = await prisma.jobCard.findUnique({
      where: { jobCardId: routeParam(req.params.jobCardId) },
    });
    if (!existing) throw new HttpError(404, "Job card not found");
    await accessibleRegion(supervisor, existing.region);
    const updates = parsed.data;
    if (updates.technicianIds) {
      const technicians = await prisma.employeeWhitelist.findMany({
        where: {
          employeeId: { in: updates.technicianIds },
          role: "Technician",
        },
      });
      if (technicians.length !== updates.technicianIds.length) {
        throw new HttpError(400, "Select valid technician employee IDs");
      }
    }
    if (
      updates.jobStatus &&
      !["Open", "In Progress", "Pending Material", "Completed / Closed", "Cancelled"].includes(
        updates.jobStatus,
      )
    ) {
      throw new HttpError(400, "Invalid job-card status");
    }
    const attachments = updates.attachments ?? [];
    if (updates.attachments) {
      if (attachments.length > 12) {
        throw new HttpError(400, "A job card can have up to twelve media files");
      }
      if (attachments.some((file) => !file.path.startsWith("/objects/uploads/"))) {
        throw new HttpError(400, "Invalid uploaded file reference");
      }
    }
    const job = await prisma.$transaction(async (tx) => {
      if (updates.technicianIds) {
        await tx.jobCardTechnician.deleteMany({
          where: { jobCardId: existing.jobCardId },
        });
        await tx.jobCardTechnician.createMany({
          data: updates.technicianIds.map((employeeId) => ({
            jobCardId: existing.jobCardId,
            employeeId,
          })),
          skipDuplicates: true,
        });
      }
      if (updates.attachments) {
        await tx.jobCardMedia.deleteMany({
          where: { jobCardId: existing.jobCardId },
        });
        if (attachments.length) {
          await tx.jobCardMedia.createMany({
            data: attachments.map((file) => ({
              jobCardId: existing.jobCardId,
              path: file.path,
              name: file.name,
              type: file.type,
            })),
          });
        }
      }
      return tx.jobCard.update({
        where: { jobCardId: existing.jobCardId },
        data: {
          ...(updates.teamName !== undefined ? { teamName: updates.teamName } : {}),
          ...(updates.repairReport !== undefined
            ? { repairReport: updates.repairReport || null }
            : {}),
          ...(updates.jobStatus !== undefined
            ? {
                jobStatus: updates.jobStatus,
                closedAt:
                  updates.jobStatus === "Completed / Closed"
                    ? new Date()
                    : updates.jobStatus === "Cancelled"
                      ? new Date()
                      : null,
              }
            : {}),
        },
        include: {
          request: { include: { employee: true } },
          supervisor: true,
          technicians: { include: { employee: true } },
          media: true,
        },
      });
    });
    res.json(mapJobCard(job));
  }),
);

router.get(
  "/mps/reports",
  endpoint(async (req, res) => {
    const employee = await requireEmployee(req, res, [
      "Admin",
      "Supervisor",
      "Storekeeper",
      "Manager",
    ]);
    if (!employee) return;
    const parsed = GetMpsReportsQueryParams.safeParse(req.query);
    if (!parsed.success) throw new HttpError(400, "Invalid report filter");
    const region = await accessibleRegion(employee, parsed.data.region);
    const dateFilter =
      parsed.data.from || parsed.data.to
        ? {
            createdAt: {
              ...(parsed.data.from ? { gte: new Date(parsed.data.from) } : {}),
              ...(parsed.data.to
                ? { lte: new Date(`${parsed.data.to}T23:59:59.999Z`) }
                : {}),
            },
          }
        : {};
    const [requests, transactions, jobs, items, technicians] = await Promise.all([
      prisma.maintenanceRequest.findMany({
        where: {
          ...(region ? { region } : { region: { in: employeeRegions(employee) } }),
          status: { not: PENDING_VERIFICATION },
          ...dateFilter,
        },
        include: { employee: true, jobCards: true, attachments: true },
        orderBy: { createdAt: "desc" },
      }),
      prisma.warehouseTransaction.findMany({
        where: {
          ...(region
            ? { OR: [{ region }, { toRegion: region }] }
            : {
                OR: [
                  { region: { in: employeeRegions(employee) } },
                  { toRegion: { in: employeeRegions(employee) } },
                ],
              }),
          ...dateFilter,
        },
        include: { item: true },
        orderBy: { createdAt: "desc" },
      }),
      prisma.jobCard.findMany({
        where: {
          ...(region ? { region } : { region: { in: employeeRegions(employee) } }),
          ...dateFilter,
          ...(parsed.data.technicianId
            ? { technicians: { some: { employeeId: parsed.data.technicianId } } }
            : {}),
        },
        include: { technicians: true },
      }),
      prisma.itemMaster.findMany({ include: { transactions: true } }),
      prisma.employeeWhitelist.findMany({
        where: {
          role: "Technician",
          ...(parsed.data.technicianId
            ? { employeeId: parsed.data.technicianId }
            : {}),
        },
        orderBy: { fullName: "asc" },
      }),
    ]);
    const technicianPerformance = technicians.map((technician) => {
      const assigned = jobs.filter((job) =>
        job.technicians.some((member) => member.employeeId === technician.employeeId),
      );
      return {
        employeeId: technician.employeeId,
        fullName: technician.fullName,
        assignedJobs: assigned.length,
        completedJobs: assigned.filter((job) => job.jobStatus === "Completed / Closed").length,
        soloJobs: assigned.filter((job) => job.technicians.length === 1).length,
        teamJobs: assigned.filter((job) => job.technicians.length > 1).length,
      };
    });
    const mappedItems = items.map((item) => mapItem(item, region));
    res.json({
      requests: requests.map(mapRequest),
      technicianPerformance,
      inventoryLedger: transactions.map(mapTransaction),
      lowStockItems: mappedItems.filter((item) => item.currentStock <= item.minStockLevel),
    });
  }),
);

router.get(
  "/mps/locations",
  endpoint(async (_req, res) => {
    const locations = await prisma.locationOption.findMany({
      orderBy: [{ region: "asc" }, { name: "asc" }],
    });
    res.json(
      locations.map((location) => ({
        name: location.name,
        region: location.region,
        status: location.status,
      })),
    );
  }),
);

router.post(
  "/mps/uploads/request-url",
  endpoint(async (req, res) => {
    const parsed = RequestMpsUploadUrlBody.safeParse(req.body);
    if (!parsed.success) throw new HttpError(400, "Invalid file upload request");
    const { name, size, contentType, purpose } = parsed.data;
    const validType =
      ["image/jpeg", "image/png", "image/webp"].includes(contentType) ||
      ["video/mp4", "video/webm"].includes(contentType) ||
      contentType === "application/pdf";
    if (!validType) throw new HttpError(400, "Unsupported file type");
    const maxSize =
      contentType.startsWith("video/") ? 100 * 1024 * 1024 : 20 * 1024 * 1024;
    if (size < 1 || size > maxSize) {
      throw new HttpError(413, "This file exceeds the allowed upload size");
    }
    if (purpose === "request") {
      // Public form: no sign-in, so cap how many upload links can be issued overall.
      const now = Date.now();
      if (now - publicUploadWindowStart > PUBLIC_UPLOAD_WINDOW_MS) {
        publicUploadWindowStart = now;
        publicUploadCount = 0;
      }
      publicUploadCount += 1;
      if (publicUploadCount > PUBLIC_UPLOADS_PER_WINDOW) {
        throw new HttpError(429, "Too many uploads right now. Please try again in a few minutes.");
      }
    } else {
      const employee = await requireEmployee(
        req,
        res,
        purpose === "job-card"
          ? ["Supervisor"]
          : ["Admin", "Supervisor", "Storekeeper"],
      );
      if (!employee) return;
    }
    const uploadURL = await objectStorage.getObjectEntityUploadURL();
    const objectPath = objectStorage.normalizeObjectEntityPath(uploadURL);
    res.json({
      uploadURL,
      objectPath,
      metadata: { name, size, contentType },
    });
  }),
);

export default router;
