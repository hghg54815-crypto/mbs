import { Router, type IRouter } from "express";
import { prisma } from "../lib/prisma";
import {
  clearSessionCookie,
  createSession,
  getSession,
  hashPassword,
  publicEmployee,
  verifyPassword,
  withEffectiveRegions,
} from "../lib/auth";

const router: IRouter = Router();
const MIN_PASSWORD_LENGTH = 12;

function validEmail(value: unknown): value is string {
  return (
    typeof value === "string" &&
    value.length <= 254 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)
  );
}

router.get("/auth/session", async (req, res): Promise<void> => {
  const session = await getSession(req);
  if (!session) {
    res.status(401).json({ error: "Sign in to continue" });
    return;
  }
  res.json({
    employee: publicEmployee(session.employee),
    mustChangePassword: session.employee.mustChangePassword,
  });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
  const temporaryPassword = req.body?.temporaryPassword;
  if (
    !validEmail(email) ||
    typeof temporaryPassword !== "string" ||
    temporaryPassword.length < 1 ||
    temporaryPassword.length > 128
  ) {
    res.status(400).json({ error: "Enter a valid email and temporary password" });
    return;
  }

  const employee = await prisma.employeeWhitelist.findUnique({
    where: { email },
    include: { regions: true },
  });
  if (
    !employee?.passwordHash ||
    employee.role === "Requester" ||
    !(await verifyPassword(temporaryPassword, employee.passwordHash))
  ) {
    res.status(401).json({ error: "Email or password is incorrect" });
    return;
  }

  await createSession(employee.employeeId, res);
  res.json({
    employee: publicEmployee(await withEffectiveRegions(employee)),
    mustChangePassword: employee.mustChangePassword,
  });
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  const session = await getSession(req);
  if (session) {
    await prisma.authSession.deleteMany({ where: { tokenHash: session.tokenHash } });
  }
  clearSessionCookie(res);
  res.status(204).end();
});

router.post("/auth/change-password", async (req, res): Promise<void> => {
  const session = await getSession(req);
  if (!session) {
    res.status(401).json({ error: "Sign in to continue" });
    return;
  }
  const { currentPassword, newPassword } = req.body ?? {};
  if (typeof currentPassword !== "string" || typeof newPassword !== "string") {
    res.status(400).json({ error: "Enter your current password and a new password" });
    return;
  }
  if (newPassword.length < MIN_PASSWORD_LENGTH || newPassword.length > 128) {
    res.status(400).json({ error: "Your new password must be 12 to 128 characters" });
    return;
  }
  if (currentPassword.length > 128) {
    res.status(400).json({ error: "Your current password is invalid" });
    return;
  }
  if (newPassword === currentPassword) {
    res.status(400).json({ error: "Choose a password different from your current one" });
    return;
  }
  if (
    !session.employee.passwordHash ||
    !(await verifyPassword(currentPassword, session.employee.passwordHash))
  ) {
    res.status(400).json({ error: "Your current password is incorrect" });
    return;
  }

  const passwordHash = await hashPassword(newPassword);
  await prisma.$transaction([
    prisma.employeeWhitelist.update({
      where: { employeeId: session.employeeId },
      data: { passwordHash, mustChangePassword: false },
    }),
    prisma.authSession.deleteMany({
      where: { employeeId: session.employeeId, tokenHash: { not: session.tokenHash } },
    }),
  ]);
  res.json({
    employee: publicEmployee(session.employee),
    mustChangePassword: false,
  });
});

export default router;
