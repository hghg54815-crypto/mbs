import {
  createHash,
  randomBytes,
  scrypt as scryptCallback,
  timingSafeEqual,
} from "node:crypto";
import type { Request, Response } from "express";
import { prisma } from "./prisma";

const PASSWORD_BYTES = 64;
const SESSION_LIFETIME_MS = 12 * 60 * 60 * 1000;
export const SESSION_COOKIE_NAME = "mps_session";

function sessionSecret() {
  const secret = process.env.SESSION_SECRET;
  if (!secret) throw new Error("SESSION_SECRET is required for local authentication");
  return secret;
}

export function hashSecret(value: string) {
  return createHash("sha256")
    .update(`${sessionSecret()}:${value}`)
    .digest("hex");
}

function derivePassword(password: string, salt: string) {
  return new Promise<Buffer>((resolve, reject) => {
    scryptCallback(password, salt, PASSWORD_BYTES, (error, key) => {
      if (error) reject(error);
      else resolve(key);
    });
  });
}

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = await derivePassword(password, salt);
  return `scrypt$${salt}$${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, storedHash: string) {
  const [algorithm, salt, encoded] = storedHash.split("$");
  if (algorithm !== "scrypt" || !salt || !encoded || !/^[a-f0-9]{128}$/i.test(encoded)) {
    return false;
  }
  const expected = Buffer.from(encoded, "hex");
  const actual = await derivePassword(password, salt);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

type RegionLink = { id: number; employeeId: string; region: string };

/** Every region name known to the system (employees, assignments, locations). */
export async function allRegionNames() {
  const [primary, assigned, locations] = await Promise.all([
    prisma.employeeWhitelist.findMany({
      where: { role: { not: "Requester" } },
      select: { region: true },
      distinct: ["region"],
    }),
    prisma.employeeRegion.findMany({ select: { region: true }, distinct: ["region"] }),
    prisma.locationOption.findMany({ select: { region: true }, distinct: ["region"] }),
  ]);
  const names = new Set<string>();
  for (const row of [...primary, ...assigned, ...locations]) {
    const region = row.region?.trim();
    if (region) names.add(region);
  }
  return Array.from(names).sort((a, b) => a.localeCompare(b));
}

/**
 * Managers are read-only users who can see every region, so their region list is
 * computed from the data instead of being stored per employee.
 */
export async function withEffectiveRegions<
  T extends { employeeId: string; role: string; regions: RegionLink[] },
>(employee: T): Promise<T> {
  if (employee.role !== "Manager") return employee;
  const names = await allRegionNames();
  return {
    ...employee,
    regions: names.map((region, index) => ({
      id: -(index + 1),
      employeeId: employee.employeeId,
      region,
    })),
  };
}

export function getSessionToken(req: Request) {
  const token = req.cookies?.[SESSION_COOKIE_NAME];
  return typeof token === "string" && token.length > 0 ? token : null;
}

export async function getSession(req: Request) {
  const token = getSessionToken(req);
  if (!token) return null;

  const tokenHash = hashSecret(token);
  const session = await prisma.authSession.findUnique({
    where: { tokenHash },
    include: { employee: { include: { regions: true } } },
  });
  if (!session) return null;
  if (session.expiresAt <= new Date()) {
    await prisma.authSession.deleteMany({ where: { tokenHash } });
    return null;
  }
  return { ...session, employee: await withEffectiveRegions(session.employee), tokenHash };
}

export async function getRequestEmployee(req: Request) {
  const session = await getSession(req);
  return session?.employee ?? null;
}

export async function createSession(employeeId: string, res: Response) {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_LIFETIME_MS);
  await prisma.authSession.create({
    data: { tokenHash: hashSecret(token), employeeId, expiresAt },
  });
  res.cookie(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/api",
    expires: expiresAt,
  });
}

export function clearSessionCookie(res: Response) {
  res.clearCookie(SESSION_COOKIE_NAME, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/api",
  });
}

export function publicEmployee(employee: {
  employeeId: string;
  fullName: string;
  email: string;
  department: string;
  region: string;
  role: string;
  regions: Array<{ region: string }>;
}) {
  const regions = employee.regions.map((entry) => entry.region);
  return {
    employeeId: employee.employeeId,
    fullName: employee.fullName,
    email: employee.email,
    department: employee.department,
    region: employee.region,
    role: employee.role,
    regions: regions.length ? regions : [employee.region],
  };
}
