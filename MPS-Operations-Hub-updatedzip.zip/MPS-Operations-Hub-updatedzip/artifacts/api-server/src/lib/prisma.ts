import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as unknown as {
  mpsPrisma?: PrismaClient;
};

export const prisma = globalForPrisma.mpsPrisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.mpsPrisma = prisma;
}
