-- CreateTable
CREATE TABLE "EmployeeWhitelist" (
    "employeeId" TEXT NOT NULL,
    "fullName" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "department" TEXT NOT NULL,
    "region" TEXT NOT NULL,
    "role" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "EmployeeWhitelist_pkey" PRIMARY KEY ("employeeId")
);

-- CreateTable
CREATE TABLE "EmployeeRegion" (
    "id" SERIAL NOT NULL,
    "employeeId" TEXT NOT NULL,
    "region" TEXT NOT NULL,

    CONSTRAINT "EmployeeRegion_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ItemMaster" (
    "itemCode" TEXT NOT NULL,
    "itemName" TEXT NOT NULL,
    "description" TEXT,
    "unitOfMeasure" TEXT NOT NULL,
    "minStockLevel" INTEGER NOT NULL DEFAULT 0,
    "binLocation" TEXT,
    "barcode" TEXT,
    "unitCost" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ItemMaster_pkey" PRIMARY KEY ("itemCode")
);

-- CreateTable
CREATE TABLE "MaintenanceRequest" (
    "requestId" TEXT NOT NULL,
    "employeeId" TEXT NOT NULL,
    "department" TEXT NOT NULL,
    "region" TEXT NOT NULL,
    "locationName" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'Pending',
    "isCustomLocation" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "MaintenanceRequest_pkey" PRIMARY KEY ("requestId")
);

-- CreateTable
CREATE TABLE "RequestAttachment" (
    "id" SERIAL NOT NULL,
    "requestId" TEXT NOT NULL,
    "path" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "RequestAttachment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "JobCard" (
    "jobCardId" TEXT NOT NULL,
    "requestId" TEXT NOT NULL,
    "teamName" TEXT NOT NULL,
    "supervisorId" TEXT NOT NULL,
    "region" TEXT NOT NULL,
    "jobStatus" TEXT NOT NULL DEFAULT 'Open',
    "repairReport" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "closedAt" TIMESTAMP(3),

    CONSTRAINT "JobCard_pkey" PRIMARY KEY ("jobCardId")
);

-- CreateTable
CREATE TABLE "JobCardTechnician" (
    "id" SERIAL NOT NULL,
    "jobCardId" TEXT NOT NULL,
    "employeeId" TEXT NOT NULL,

    CONSTRAINT "JobCardTechnician_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "JobCardMedia" (
    "id" SERIAL NOT NULL,
    "jobCardId" TEXT NOT NULL,
    "path" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "JobCardMedia_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WarehouseTransaction" (
    "transactionId" SERIAL NOT NULL,
    "transactionType" TEXT NOT NULL,
    "itemCode" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "employeeId" TEXT NOT NULL,
    "employeeNameSnapshot" TEXT NOT NULL,
    "recordedById" TEXT NOT NULL,
    "jobCardId" TEXT,
    "referenceNo" TEXT,
    "supplierName" TEXT,
    "purchaseType" TEXT,
    "invoiceDate" TIMESTAMP(3),
    "region" TEXT NOT NULL,
    "toRegion" TEXT,
    "unitCostAtTransaction" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "WarehouseTransaction_pkey" PRIMARY KEY ("transactionId")
);

-- CreateTable
CREATE TABLE "IdSequence" (
    "key" TEXT NOT NULL,
    "value" INTEGER NOT NULL,

    CONSTRAINT "IdSequence_pkey" PRIMARY KEY ("key")
);

-- CreateTable
CREATE TABLE "LocationOption" (
    "id" SERIAL NOT NULL,
    "name" TEXT NOT NULL,
    "region" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'Approved',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "LocationOption_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AppTranslation" (
    "key" TEXT NOT NULL,
    "en" TEXT NOT NULL,
    "ar" TEXT NOT NULL,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AppTranslation_pkey" PRIMARY KEY ("key")
);

-- CreateTable
CREATE TABLE "OtpChallenge" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "codeHash" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "verifiedTokenHash" TEXT,
    "verificationExpiresAt" TIMESTAMP(3),
    "consumedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "OtpChallenge_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "EmployeeWhitelist_email_key" ON "EmployeeWhitelist"("email");

-- CreateIndex
CREATE UNIQUE INDEX "EmployeeRegion_employeeId_region_key" ON "EmployeeRegion"("employeeId", "region");

-- CreateIndex
CREATE UNIQUE INDEX "JobCardTechnician_jobCardId_employeeId_key" ON "JobCardTechnician"("jobCardId", "employeeId");

-- CreateIndex
CREATE INDEX "WarehouseTransaction_itemCode_region_createdAt_idx" ON "WarehouseTransaction"("itemCode", "region", "createdAt");

-- CreateIndex
CREATE INDEX "WarehouseTransaction_jobCardId_idx" ON "WarehouseTransaction"("jobCardId");

-- CreateIndex
CREATE UNIQUE INDEX "LocationOption_name_region_key" ON "LocationOption"("name", "region");

-- CreateIndex
CREATE INDEX "OtpChallenge_email_createdAt_idx" ON "OtpChallenge"("email", "createdAt");

-- AddForeignKey
ALTER TABLE "EmployeeRegion" ADD CONSTRAINT "EmployeeRegion_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES "EmployeeWhitelist"("employeeId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MaintenanceRequest" ADD CONSTRAINT "MaintenanceRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES "EmployeeWhitelist"("employeeId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RequestAttachment" ADD CONSTRAINT "RequestAttachment_requestId_fkey" FOREIGN KEY ("requestId") REFERENCES "MaintenanceRequest"("requestId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "JobCard" ADD CONSTRAINT "JobCard_requestId_fkey" FOREIGN KEY ("requestId") REFERENCES "MaintenanceRequest"("requestId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "JobCard" ADD CONSTRAINT "JobCard_supervisorId_fkey" FOREIGN KEY ("supervisorId") REFERENCES "EmployeeWhitelist"("employeeId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "JobCardTechnician" ADD CONSTRAINT "JobCardTechnician_jobCardId_fkey" FOREIGN KEY ("jobCardId") REFERENCES "JobCard"("jobCardId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "JobCardTechnician" ADD CONSTRAINT "JobCardTechnician_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES "EmployeeWhitelist"("employeeId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "JobCardMedia" ADD CONSTRAINT "JobCardMedia_jobCardId_fkey" FOREIGN KEY ("jobCardId") REFERENCES "JobCard"("jobCardId") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WarehouseTransaction" ADD CONSTRAINT "WarehouseTransaction_itemCode_fkey" FOREIGN KEY ("itemCode") REFERENCES "ItemMaster"("itemCode") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WarehouseTransaction" ADD CONSTRAINT "WarehouseTransaction_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES "EmployeeWhitelist"("employeeId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WarehouseTransaction" ADD CONSTRAINT "WarehouseTransaction_recordedById_fkey" FOREIGN KEY ("recordedById") REFERENCES "EmployeeWhitelist"("employeeId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WarehouseTransaction" ADD CONSTRAINT "WarehouseTransaction_jobCardId_fkey" FOREIGN KEY ("jobCardId") REFERENCES "JobCard"("jobCardId") ON DELETE SET NULL ON UPDATE CASCADE;
