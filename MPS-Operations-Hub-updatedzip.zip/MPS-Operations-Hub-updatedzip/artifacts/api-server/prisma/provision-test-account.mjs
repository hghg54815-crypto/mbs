import { createHash, randomBytes, scryptSync } from "node:crypto";
import { PrismaClient } from "@prisma/client";

if (process.env.NODE_ENV === "production") {
  throw new Error("The demo test account can only be provisioned in development.");
}
if (!process.env.SESSION_SECRET) {
  throw new Error("SESSION_SECRET is required before provisioning a local-auth account.");
}

const prisma = new PrismaClient();
const employeeId = "MPS-DEMO-ADMIN";
const email = "mps-test-admin@example.test";
const password = randomBytes(18).toString("base64url");
const salt = randomBytes(16).toString("hex");
const passwordHash = `scrypt$${salt}$${scryptSync(password, salt, 64).toString("hex")}`;

try {
  const employee = await prisma.employeeWhitelist.upsert({
    where: { employeeId },
    create: {
      employeeId,
      fullName: "MPS Test Administrator",
      email,
      department: "Operations",
      region: "Dammam",
      role: "Admin",
      passwordHash,
      mustChangePassword: true,
    },
    update: {
      fullName: "MPS Test Administrator",
      email,
      department: "Operations",
      region: "Dammam",
      role: "Admin",
      passwordHash,
      mustChangePassword: true,
    },
  });

  await prisma.$transaction([
    prisma.employeeRegion.deleteMany({ where: { employeeId } }),
    prisma.employeeRegion.createMany({
      data: [{ employeeId, region: "Dammam" }],
    }),
    prisma.authSession.deleteMany({ where: { employeeId } }),
  ]);

  console.log(JSON.stringify({ email: employee.email, temporaryPassword: password }));
} finally {
  await prisma.$disconnect();
}
