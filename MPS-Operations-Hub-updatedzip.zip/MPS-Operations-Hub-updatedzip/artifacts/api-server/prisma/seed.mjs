import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const employees = [
  {
    employeeId: "MPS-A001",
    fullName: "Sara Al Mutairi",
    email: "admin@example.com",
    department: "Operations",
    region: "Dammam",
    role: "Admin",
    regions: ["Dammam", "Riyadh", "Jeddah"],
  },
  {
    employeeId: "MPS-S012",
    fullName: "Fahad Al Qahtani",
    email: "supervisor@example.com",
    department: "Maintenance",
    region: "Dammam",
    role: "Supervisor",
    regions: ["Dammam", "Riyadh", "Jeddah"],
  },
  {
    employeeId: "MPS-W021",
    fullName: "Nasser Al Harbi",
    email: "storekeeper@example.com",
    department: "Warehouse",
    region: "Dammam",
    role: "Storekeeper",
    regions: ["Dammam"],
  },
  {
    employeeId: "MPS-T031",
    fullName: "Omar Al Dosari",
    email: "technician.one@example.com",
    department: "Mechanical",
    region: "Dammam",
    role: "Technician",
    regions: ["Dammam"],
  },
  {
    employeeId: "MPS-T032",
    fullName: "Hala Al Otaibi",
    email: "technician.two@example.com",
    department: "Electrical",
    region: "Dammam",
    role: "Technician",
    regions: ["Dammam"],
  },
  {
    employeeId: "MPS-E041",
    fullName: "Maha Al Shammari",
    email: "requester@example.com",
    department: "Facilities",
    region: "Dammam",
    role: "Technician",
    regions: ["Dammam"],
  },
];

async function main() {
  for (const employee of employees) {
    const { regions, ...data } = employee;
    await prisma.employeeWhitelist.upsert({
      where: { employeeId: data.employeeId },
      create: data,
      update: data,
    });
    await prisma.employeeRegion.deleteMany({
      where: { employeeId: data.employeeId },
    });
    await prisma.employeeRegion.createMany({
      data: regions.map((region) => ({ employeeId: data.employeeId, region })),
      skipDuplicates: true,
    });
  }

  const items = [
    {
      itemCode: "PMP-SEAL-007",
      itemName: "Mechanical seal kit",
      description: "Standard pump seal service kit",
      unitOfMeasure: "EA",
      minStockLevel: 8,
      binLocation: "A-03-02",
      barcode: "6281007007007",
      unitCost: 185,
    },
    {
      itemCode: "FLT-IND-014",
      itemName: "Industrial air filter",
      description: "Panel filter, 600 × 600 mm",
      unitOfMeasure: "EA",
      minStockLevel: 12,
      binLocation: "B-01-04",
      barcode: "6281007014014",
      unitCost: 72.5,
    },
    {
      itemCode: "BLT-SS-008",
      itemName: "Stainless hex bolt M8",
      description: "A4 stainless steel, 40 mm",
      unitOfMeasure: "EA",
      minStockLevel: 50,
      binLocation: "C-02-01",
      barcode: "6281007008008",
      unitCost: 2.4,
    },
    {
      itemCode: "CAB-GL-025",
      itemName: "Control cable 2.5 mm",
      description: "Industrial-grade copper cable",
      unitOfMeasure: "M",
      minStockLevel: 100,
      binLocation: "D-04-03",
      barcode: "6281007025025",
      unitCost: 8.75,
    },
  ];

  for (const item of items) {
    await prisma.itemMaster.upsert({
      where: { itemCode: item.itemCode },
      create: item,
      update: item,
    });
  }

  const locations = [
    ["Dammam Plant 1", "Dammam"],
    ["Dammam Plant 2", "Dammam"],
    ["Jubail Workshop", "Dammam"],
    ["Riyadh Service Center", "Riyadh"],
    ["Jeddah Depot", "Jeddah"],
  ];
  for (const [name, region] of locations) {
    await prisma.locationOption.upsert({
      where: { name_region: { name, region } },
      create: { name, region, status: "Approved" },
      update: { status: "Approved" },
    });
  }

  const requests = [
    {
      requestId: "REQ-2026-0001",
      employeeId: "MPS-E041",
      department: "Facilities",
      region: "Dammam",
      locationName: "Dammam Plant 1",
      description: "Cooling pump vibration is above the normal operating range.",
      status: "Approved",
    },
    {
      requestId: "REQ-2026-0002",
      employeeId: "MPS-E041",
      department: "Facilities",
      region: "Dammam",
      locationName: "Jubail Workshop",
      description: "Replace two damaged lighting fixtures in the inspection bay.",
      status: "Pending",
    },
    {
      requestId: "REQ-2026-0003",
      employeeId: "MPS-E041",
      department: "Facilities",
      region: "Dammam",
      locationName: "Dammam Plant 2",
      description: "Compressed air line has a leak near the west service point.",
      status: "Pending",
    },
  ];
  for (const request of requests) {
    await prisma.maintenanceRequest.upsert({
      where: { requestId: request.requestId },
      create: request,
      update: request,
    });
  }

  const jobCards = [
    {
      jobCardId: "DAMMAM-TEAM-2026-0012",
      requestId: "REQ-2026-0001",
      teamName: "Pump Response Team",
      supervisorId: "MPS-S012",
      region: "Dammam",
      jobStatus: "In Progress",
      technicians: ["MPS-T031", "MPS-T032"],
    },
    {
      jobCardId: "DAMMAM-TEAM-2026-0013",
      requestId: "REQ-2026-0002",
      teamName: "Electrical Maintenance",
      supervisorId: "MPS-S012",
      region: "Dammam",
      jobStatus: "Open",
      technicians: ["MPS-T032"],
    },
  ];
  for (const job of jobCards) {
    const { technicians, ...data } = job;
    const existing = await prisma.jobCard.findUnique({
      where: { jobCardId: job.jobCardId },
    });
    if (!existing) {
      await prisma.jobCard.create({
        data: {
          ...data,
          technicians: {
            create: technicians.map((employeeId) => ({ employeeId })),
          },
        },
      });
    }
  }

  const seededReceipt = await prisma.warehouseTransaction.findFirst({
    where: { referenceNo: "PO-450218", itemCode: "PMP-SEAL-007" },
  });
  if (!seededReceipt) {
    await prisma.warehouseTransaction.create({
      data: {
        transactionType: "IN",
        itemCode: "PMP-SEAL-007",
        quantity: 18,
        employeeId: "MPS-W021",
        employeeNameSnapshot: "Nasser Al Harbi",
        recordedById: "MPS-W021",
        referenceNo: "PO-450218",
        supplierName: "Gulf Industrial Supply",
        purchaseType: "PO",
        invoiceDate: new Date("2026-10-22T08:30:00.000Z"),
        region: "Dammam",
        unitCostAtTransaction: 185,
        createdAt: new Date("2026-10-22T08:30:00.000Z"),
      },
    });
  }

  const seededBolts = await prisma.warehouseTransaction.findFirst({
    where: { referenceNo: "CASH-RECEIPT-091", itemCode: "BLT-SS-008" },
  });
  if (!seededBolts) {
    await prisma.warehouseTransaction.create({
      data: {
        transactionType: "IN",
        itemCode: "BLT-SS-008",
        quantity: 120,
        employeeId: "MPS-W021",
        employeeNameSnapshot: "Nasser Al Harbi",
        recordedById: "MPS-W021",
        referenceNo: "CASH-RECEIPT-091",
        supplierName: "Eastern Fasteners",
        purchaseType: "Cash",
        invoiceDate: new Date("2026-10-28T08:30:00.000Z"),
        region: "Dammam",
        unitCostAtTransaction: 2.4,
        createdAt: new Date("2026-10-28T08:30:00.000Z"),
      },
    });
  }

  await prisma.idSequence.upsert({
    where: { key: "request:2026" },
    create: { key: "request:2026", value: 3 },
    update: {},
  });
  await prisma.idSequence.upsert({
    where: { key: "jobcard:DAMMAM:2026" },
    create: { key: "jobcard:DAMMAM:2026", value: 13 },
    update: {},
  });
}

main()
  .catch((error) => {
    process.stderr.write(`MPS seed failed: ${error instanceof Error ? error.message : String(error)}\n`);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
