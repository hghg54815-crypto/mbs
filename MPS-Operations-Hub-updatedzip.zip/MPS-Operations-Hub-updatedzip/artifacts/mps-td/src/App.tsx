import { createContext, useContext, useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQuery, useQueryClient } from '@tanstack/react-query';
import * as XLSX from 'xlsx';
import { Link, Redirect, Route, Router as WouterRouter, Switch, useLocation } from 'wouter';
import {
  Activity, ArrowDownToLine, ArrowLeftRight, ArrowUpFromLine, BarChart3, Bell, Boxes, BriefcaseBusiness,
  Check, ChevronDown, ClipboardList, Clock3, Download, FileText, Gauge, HardHat,
  LayoutDashboard, LogOut, MapPin, Menu, Package, Plus, Search, Settings2, ShieldCheck, Truck, UserRound,
  Users, Wrench, X, RefreshCw, Upload, Mail, ArrowRight, AlertTriangle, MessageCircle,
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import {
  useGetMpsDashboard, getGetMpsDashboardQueryKey, useGetCurrentEmployee, getGetCurrentEmployeeQueryKey,
  useListItems, getListItemsQueryKey, useCreateItem, useUpdateItem,
  useListTransactions, getListTransactionsQueryKey, useCreateTransaction,
  useListEmployees, getListEmployeesQueryKey, useCreateEmployee, useUpdateEmployee, useDeleteEmployee,
  useListRegions, getListRegionsQueryKey, useListRequesters, getListRequestersQueryKey,
  useVerifyRequester, useRejectRequester, useGetEmployeeActiveJobs,
  getGetEmployeeActiveJobsQueryKey, useListMaintenanceRequests, getListMaintenanceRequestsQueryKey,
  useSubmitMaintenanceRequest, useLookupRequester,
  useListJobCards, getListJobCardsQueryKey, useCreateJobCard, useUpdateJobCard, useUpdateMaintenanceRequest,
  useGetMpsReports, getGetMpsReportsQueryKey, useListLocations, getListLocationsQueryKey,
  useRequestMpsUploadUrl,
} from '@workspace/api-client-react';
import type { Employee, InventoryItem, JobCard, MaintenanceRequest, MediaFile, Requester } from '@workspace/api-client-react';
import NotFound from '@/pages/not-found';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const authSessionQueryKey = ['auth', 'session'] as const;
type AuthSession = { employee: Employee; mustChangePassword: boolean };

async function loadAuthSession(): Promise<AuthSession | null> {
  const response = await fetch('/api/auth/session', { credentials: 'same-origin' });
  if (response.status === 401) return null;
  if (!response.ok) throw new Error('Unable to load your sign-in session.');
  return response.json() as Promise<AuthSession>;
}

function useAuthSession() {
  return useQuery({ queryKey: authSessionQueryKey, queryFn: loadAuthSession, retry: false });
}

const links = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, group: 'OPERATIONS' },
  { href: '/requests', label: 'Requests', icon: ClipboardList },
  { href: '/job-cards', label: 'Job cards', icon: BriefcaseBusiness },
  { href: '/inventory', label: 'Inventory', icon: Boxes, group: 'WAREHOUSE' },
  { href: '/storekeeper', label: 'Warehouse desk', icon: ArrowLeftRight },
  { href: '/reports', label: 'Reports', icon: BarChart3, group: 'INSIGHTS' },
  { href: '/admin/employees', label: 'Employees', icon: Users, group: 'ADMIN' },
];
type AppContextType = { employee: Employee; region: string; setRegion: (region: string) => void };
const AppContext = createContext<AppContextType | null>(null);
function useApp() { const value = useContext(AppContext); if (!value) throw new Error('App context unavailable'); return value; }
/** Strips the "HTTP 409 Conflict:" prefix the API client adds so people see the plain message. */
function apiMessage(error: unknown, fallback: string) {
  const raw = error instanceof Error ? error.message : '';
  const cleaned = raw.replace(/^HTTP \d+[^:]*:\s*/, '').trim();
  return cleaned || fallback;
}
/** Signed-in (or remembered) person shown next to the sign-in / sign-out button on every screen. */
function UserChip({ name, role }: { name: string; role?: string }) {
  const initials = name.split(/[\s@.]+/).filter(Boolean).map(part => part[0]).join('').slice(0, 2).toUpperCase();
  return <span className="user-chip" title={role ? `${name} · ${role}` : name} data-testid="text-current-user"><span className="avatar">{initials || '?'}</span><span className="user-meta"><b>{name}</b>{role && <small>{role}</small>}</span></span>;
}
function RoleGate({roles,children}:{roles:Employee['role'][];children:ReactNode}){const {employee}=useApp();return roles.includes(employee.role)?<>{children}</>:<main className="page-wrap"><PageHeading eyebrow="ACCESS CONTROL" title="Role access required"/><section className="panel empty-state"><div className="empty-icon"><ShieldCheck size={20}/></div><h3>This workspace view is not available to your role</h3><p>Contact an MPS administrator if you need access to this operational area.</p></section></main>;}

function LoadingPanel({ count = 3 }: { count?: number }) { return <div className="space-y-3" aria-label="Loading">{Array.from({ length: count }, (_, i) => <div className="skeleton skeleton-block" key={i} />)}</div>; }
function ErrorPanel({ retry }: { retry: () => void }) { return <div className="panel empty-state"><div className="empty-icon"><AlertTriangle size={20} /></div><h3>We couldn’t load this view</h3><p>Check your connection, then try again.</p><button className="button outline small" onClick={retry} data-testid="button-retry"><RefreshCw size={13} /> Retry</button></div>; }
function PageHeading({ eyebrow, title, subtitle, action }: { eyebrow: string; title: string; subtitle?: string; action?: ReactNode }) { return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1 className="page-title">{title}</h1>{subtitle && <p className="page-subtitle">{subtitle}</p>}</div>{action}</div>; }
function Badge({ text }: { text: string }) { const low = text.toLowerCase(); const color = /closed|complete|approved|in stock|open$/.test(low) ? '' : /progress|issued|pending|transfer/.test(low) ? 'amber' : /low|urgent|overdue|rejected/.test(low) ? 'red' : 'blue'; return <span className={`badge ${color}`}>{text.replaceAll('_', ' ')}</span>; }
function SearchBox({ value, onChange, placeholder = 'Search records' }: { value: string; onChange: (v: string) => void; placeholder?: string }) { return <div className="search-field"><Search /><input className="input" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} aria-label={placeholder} data-testid="input-search" /></div>; }
function Table({ headers, children, minWidth }: { headers: string[]; children: ReactNode; minWidth?: number }) { return <div className="table-wrap"><table style={{ minWidth }}><thead><tr>{headers.map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{children}</tbody></table></div>; }
function Empty({ title, body }: { title: string; body: string }) { return <div className="empty-state"><div className="empty-icon"><Package size={20} /></div><h3>{title}</h3><p>{body}</p></div>; }
function TextField({ label, value, onChange, placeholder, type = 'text', required = false }: { label: string; value: string | number; onChange: (v: string) => void; placeholder?: string; type?: string; required?: boolean }) { return <div className="field"><label>{label}</label><input className="input" type={type} required={required} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} /></div>; }

function PublicHome() {
  const auth = useAuthSession();
  if (auth.data) return <Redirect to={auth.data.mustChangePassword ? '/change-password' : '/dashboard'} />;
  return <main className="hero-public">
     <header className="hero-nav"><Link href="/" className="brand-lockup" style={{ padding: 0, textDecoration: 'none', color: 'inherit' }}><span className="brand-mark">M</span><span><span className="brand-title">MPS — TD</span><small className="brand-sub">MAINTENANCE OPERATIONS</small></span></Link><div className="top-actions"><Link href="/request" className="button outline small">Submit a request</Link><Link href="/sign-in" className="button primary small">Staff sign in <ArrowRight size={14} /></Link></div></header>
    <section className="hero-body"><div><div className="hero-kicker">Field service, in good order</div><h1 className="hero-title">Keep the work<br />moving <em>forward.</em></h1><p className="hero-copy">One dependable workspace for maintenance teams, warehouse operations, and the people who keep every site running.</p><div className="hero-ctas"><Link href="/request" className="button gold">Request maintenance <ArrowRight size={16} /></Link><Link href="/sign-in" className="button outline">Team workspace</Link></div><div className="public-strip"><span>Maintenance</span><span>Inventory</span><span>Field teams</span><span>One system</span></div></div>
      <div className="hero-visual" aria-label="Maintenance operations visual"><div className="visual-grid" /><div className="signal-card"><div className="signal-head">Operations pulse · today</div><div className="signal-value">On track</div><div className="signal-foot">Service teams are moving</div></div><div className="visual-note"><small>BUILT FOR THE WORKDAY</small><h2>From first report to final repair.</h2><p>Clear ownership. The right parts. A complete record at every handoff.</p></div></div>
    </section>
    <section style={{ maxWidth: 1250, margin: 'auto', padding: '0 32px 60px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(190px,1fr))', gap: 14 }}>
      {[['01','Report clearly','Send a maintenance request with the location and details teams need.'],['02','Assign with context','Supervisors coordinate people, materials, and job cards in one place.'],['03','Close the loop','Track each handoff from store issue through completed repair.']].map(([n,t,d])=><article className="panel" key={n} style={{ padding: 20 }}><span className="font-mono" style={{ color:'#b48236', fontSize:11 }}>{n} / SYSTEM</span><h2 className="font-display" style={{ color:'#274249',fontSize:16,margin:'17px 0 8px' }}>{t}</h2><p style={{ color:'#71807b',fontSize:12,lineHeight:1.7,margin:0 }}>{d}</p></article>)}
    </section>
  </main>;
}

const REQUESTER_STORAGE_KEY = 'mps_requester';
type RememberedRequester = { email: string; fullName: string };
function readRequester(): RememberedRequester | null {
  try {
    const raw = window.localStorage.getItem(REQUESTER_STORAGE_KEY);
    if (!raw) return null;
    const value = JSON.parse(raw) as Partial<RememberedRequester>;
    return typeof value.email === 'string' && typeof value.fullName === 'string' ? { email: value.email, fullName: value.fullName } : null;
  } catch { return null; }
}
function saveRequester(value: RememberedRequester | null) {
  try {
    if (value) window.localStorage.setItem(REQUESTER_STORAGE_KEY, JSON.stringify(value));
    else window.localStorage.removeItem(REQUESTER_STORAGE_KEY);
  } catch { /* storage may be unavailable (private mode); the form still works */ }
}
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
type RequesterStatus = 'New' | 'Pending' | 'Verified' | 'Rejected';

function PublicRequest() {
  const lookup = useLookupRequester(); const submit = useSubmitMaintenanceRequest(); const upload = useRequestMpsUploadUrl(); const locationsQ = useListLocations();
  const [requester, setRequester] = useState<RememberedRequester | null>(() => readRequester());
  const [email, setEmail] = useState(requester?.email ?? ''); const [fullName, setFullName] = useState(requester?.fullName ?? '');
  const [status, setStatus] = useState<RequesterStatus | null>(null);
  const [department, setDepartment] = useState(''); const [region, setRegion] = useState(''); const [location, setLocation] = useState(''); const [custom, setCustom] = useState(false);
  const [description, setDescription] = useState(''); const [files, setFiles] = useState<MediaFile[]>([]); const [busy, setBusy] = useState(false); const [err, setErr] = useState('');
  const [done, setDone] = useState<{ requestId: string; waiting: boolean } | null>(null);
  const locations = locationsQ.data ?? [];
  const regions = Array.from(new Set(locations.map(l => l.region))).sort();
  const needsName = status === null || status === 'New';

  const checkEmail = async (value: string) => {
    const clean = value.trim();
    if (!EMAIL_PATTERN.test(clean)) { setStatus(null); return; }
    try { const result = await lookup.mutateAsync({ data: { email: clean } }); setStatus(result.status); } catch { setStatus(null); }
  };
  useEffect(() => { if (requester?.email) void checkEmail(requester.email); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const addFiles = async (list: FileList | null) => {
    if (!list) return;
    const accepted = Array.from(list).filter(f => f.type.startsWith('image/') || f.type.startsWith('video/'));
    let imgs = files.filter(f => f.type.startsWith('image')).length; let vids = files.filter(f => f.type.startsWith('video')).length;
    const adds: File[] = [];
    for (const f of accepted) { if (f.type.startsWith('image/') && imgs < 2) { adds.push(f); imgs++; } else if (f.type.startsWith('video/') && vids < 1) { adds.push(f); vids++; } }
    setBusy(true); setErr('');
    try {
      const saved = [...files];
      for (const file of adds) {
        const data = await upload.mutateAsync({ data: { name: file.name, size: file.size, contentType: file.type, purpose: 'request' } });
        const response = await fetch(data.uploadURL, { method: 'PUT', headers: { 'Content-Type': file.type }, body: file });
        if (!response.ok) throw new Error('Upload failed. Please select the media again.');
        saved.push({ path: data.objectPath, name: file.name, type: file.type });
      }
      setFiles(saved);
    } catch (e) { setErr(apiMessage(e, 'Could not upload this file.')); } finally { setBusy(false); }
  };

  const sendRequest = async (e: FormEvent) => {
    e.preventDefault(); setErr('');
    if (status === 'Rejected') { setErr('This email was not approved to send maintenance requests. Contact your administrator.'); return; }
    if (!EMAIL_PATTERN.test(email.trim())) { setErr('Enter a valid work email.'); return; }
    if (needsName && fullName.trim().length < 2) { setErr('Enter your full name.'); return; }
    if (!region) { setErr('Choose a region.'); return; }
    try {
      const result = await submit.mutateAsync({ data: { email: email.trim(), fullName: needsName ? fullName.trim() : undefined, department, region, locationName: location, isCustomLocation: custom, description, attachments: files } });
      const remembered = { email: email.trim().toLowerCase(), fullName: needsName ? fullName.trim() : (requester?.email === email.trim().toLowerCase() ? requester.fullName : '') };
      saveRequester(remembered); setRequester(remembered);
      setStatus(result.status === 'Pending Verification' ? 'Pending' : 'Verified');
      setDone({ requestId: result.requestId, waiting: result.status === 'Pending Verification' });
    } catch (e2) { setErr(apiMessage(e2, 'Request could not be submitted. Please retry.')); }
  };
  const forgetMe = () => { saveRequester(null); setRequester(null); setEmail(''); setFullName(''); setStatus(null); setErr(''); };
  const another = () => { setDone(null); setDescription(''); setLocation(''); setCustom(false); setFiles([]); setErr(''); };

  return <main className="request-shell"><header className="hero-nav" style={{ height: 55, padding: 0, maxWidth: 900 }}><Link href="/" className="brand-lockup" style={{ padding: 0, textDecoration: 'none', color: 'inherit' }}><span className="brand-mark">M</span><span><span className="brand-title">MPS — TD</span><small className="brand-sub">MAINTENANCE REQUEST</small></span></Link><div className="top-actions">{requester && <UserChip name={requester.fullName || requester.email} />}<Link href="/sign-in" className="button ghost small">Team sign in</Link></div></header><section className="panel request-card">
    <div className="flow-top"><div><div className="eyebrow">PUBLIC SERVICE PORTAL</div><h1 className="page-title" style={{ fontSize: 27 }}>Request maintenance</h1></div></div>
    {done ? <div className="empty-state"><div className="empty-icon"><Check size={22} /></div><h3>{done.waiting ? 'Request received — awaiting verification' : 'Request received'}</h3>
      <p>{done.waiting ? `Reference ${done.requestId}. Your email has not been verified yet. An administrator will verify it, then your request goes to the maintenance team. After that, your requests are accepted directly.` : `Reference ${done.requestId}. Your maintenance request has been recorded and your team will review it shortly.`}</p>
      <div style={{ display: 'flex', gap: 9, justifyContent: 'center', flexWrap: 'wrap', marginTop: 18 }}><button className="button primary" onClick={another}>Send another request</button><Link href="/" className="button outline">Return to MPS — TD</Link></div></div>
    : <form onSubmit={sendRequest}>
      <div className="field-grid">
        <div className="field"><label>Work email</label><input className="input" type="email" required value={email} placeholder="name@company.com" onChange={e => { setEmail(e.target.value); setStatus(null); }} onBlur={() => void checkEmail(email)} data-testid="input-requester-email" /></div>
        {needsName && <div className="field"><label>Full name</label><input className="input" required value={fullName} onChange={e => setFullName(e.target.value)} placeholder="Your full name" data-testid="input-requester-name" /></div>}
      </div>
      {status === 'Verified' && <div className="alert-box success" style={{ marginTop: 12 }}><ShieldCheck size={16} /><div>Your email is verified. Your request goes straight to the maintenance team.</div></div>}
      {status === 'Pending' && <div className="alert-box" style={{ marginTop: 12 }}><Clock3 size={16} /><div>Your email is awaiting verification. You can still send your request; it will be processed once an administrator approves your email.</div></div>}
      {status === 'New' && <div className="alert-box" style={{ marginTop: 12 }}><Mail size={16} /><div>First time here? Your request is saved right away and processed after an administrator verifies your email. Later requests are accepted directly.</div></div>}
      {status === 'Rejected' && <div className="alert-box" role="alert" style={{ marginTop: 12 }}><AlertTriangle size={16} /><div>This email was not approved to send maintenance requests. Contact your administrator.</div></div>}
      {requester && <div style={{ marginTop: 8 }}><button type="button" className="button ghost small" onClick={forgetMe}>Not you? Use a different email</button></div>}
      <div className="field-grid" style={{ marginTop: 14 }}><div className="field"><label>Department</label><input className="input" list="mps-departments" value={department} onChange={e => setDepartment(e.target.value)} required placeholder="Search or enter department" /><datalist id="mps-departments">{['Facilities', 'Operations', 'Maintenance', 'Administration', 'IT', 'Safety', 'Warehouse'].map(d => <option key={d} value={d} />)}</datalist></div>
        <div className="field"><label>Region</label><select className="select" required value={region} onChange={e => { setRegion(e.target.value); setLocation(''); setCustom(false); }}><option value="">Choose region</option>{regions.map(r => <option key={r} value={r}>{r}</option>)}</select></div>
        <div className="field"><label>Location</label><input className="input" list="mps-locations" value={location} onChange={e => { const value = e.target.value; if (value === 'Other') { setLocation(''); setCustom(true); } else { setLocation(value); setCustom(Boolean(value) && !locations.some(l => l.name === value && (region === '' || l.region === region))); } }} required placeholder="Search or enter location" /><datalist id="mps-locations">{locations.filter(l => !region || l.region === region).map(l => <option key={`${l.region}-${l.name}`} value={l.name} />)}<option value="Other" /></datalist>{custom && <small className="pending-review-note">Unlisted location will be saved as Pending Review.</small>}</div></div>
      <div className="field" style={{ marginTop: 14 }}><label>What needs attention?</label><textarea className="textarea" value={description} onChange={e => setDescription(e.target.value)} minLength={5} required placeholder="Describe the issue, including anything the maintenance team should know." /></div>
      <div className="field" style={{ marginTop: 14 }}><label>Photos or video <span style={{ fontWeight: 400 }}>— up to 2 photos and 1 video</span></label><label className="button outline" style={{ width: 'fit-content', cursor: 'pointer' }}><Upload size={14} /> Add media<input type="file" accept="image/*,video/*" multiple hidden onChange={e => void addFiles(e.target.files)} /></label><div style={{ fontSize: 11, color: '#71807b' }}>{files.map(f => f.name).join(' · ') || 'No attachments selected'}</div></div>
      <div style={{ display: 'flex', gap: 9, marginTop: 19 }}><button className="button primary" disabled={submit.isPending || busy || status === 'Rejected'} data-testid="button-submit-request">{busy ? 'Uploading media…' : submit.isPending ? 'Submitting…' : 'Submit request'} <ArrowRight size={15} /></button></div>
    </form>}
    {err && <div role="alert" className="alert-box" style={{ marginTop: 15 }}><AlertTriangle size={16} />{err}</div>}
  </section><p style={{ textAlign: 'center', fontSize: 10, color: '#82908a' }}>Your email is checked once · Media is attached to your request</p></main>;
}

function SignInPage(){
  const auth=useAuthSession();const qc=useQueryClient();const [,setLocation]=useLocation();const [email,setEmail]=useState('');const [temporaryPassword,setTemporaryPassword]=useState('');const [error,setError]=useState('');const [busy,setBusy]=useState(false);
  if(auth.isLoading)return <div className="request-shell"><LoadingPanel count={2}/></div>;
  if(auth.data)return <Redirect to={auth.data.mustChangePassword?'/change-password':'/dashboard'}/>;
  const submit=async(e:FormEvent)=>{e.preventDefault();setError('');setBusy(true);try{const response=await fetch('/api/auth/login',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,temporaryPassword})});const data=await response.json().catch(()=>null);if(!response.ok)throw new Error(data?.error??'Sign in failed. Please try again.');qc.setQueryData(authSessionQueryKey,data as AuthSession);setLocation(data.mustChangePassword?'/change-password':'/dashboard');}catch(e){setError(e instanceof Error?e.message:'Unable to sign in. Please try again.');}finally{setBusy(false);}};
  return <div className="request-shell" style={{display:'grid',placeItems:'center'}}><section className="panel request-card" style={{width:'min(100%,460px)',margin:'auto'}}><div className="brand-lockup" style={{justifyContent:'center',padding:15}}><span className="brand-mark">M</span><span><span className="brand-title">MPS — TD</span><small className="brand-sub">FIELD OPERATIONS WORKSPACE</small></span></div><h1 className="page-title" style={{textAlign:'center',fontSize:25}}>Staff sign in</h1><p className="page-subtitle" style={{textAlign:'center',marginBottom:20}}>Use your work email and temporary password.</p><form onSubmit={submit}><TextField label="Work email" value={email} onChange={setEmail} type="email" required/><div className="field" style={{marginTop:14}}><label htmlFor="temporary-password">Temporary password</label><input id="temporary-password" className="input" type="password" value={temporaryPassword} onChange={e=>setTemporaryPassword(e.target.value)} required autoComplete="current-password"/></div>{error&&<div className="alert-box" role="alert" style={{marginTop:14}}><AlertTriangle size={16}/>{error}</div>}<button className="button primary" style={{width:'100%',justifyContent:'center',marginTop:18}} disabled={busy}>{busy?'Signing in…':'Sign in'} <ArrowRight size={15}/></button></form><p style={{textAlign:'center',fontSize:12,color:'#71807b',margin:'18px 0 0'}}>Accounts are issued by an MPS administrator.</p></section></div>;
}

function ChangePasswordPage(){
  const auth=useAuthSession();const qc=useQueryClient();const [,setLocation]=useLocation();const [currentPassword,setCurrentPassword]=useState('');const [newPassword,setNewPassword]=useState('');const [confirmPassword,setConfirmPassword]=useState('');const [error,setError]=useState('');const [busy,setBusy]=useState(false);
  if(auth.isLoading)return <div className="request-shell"><LoadingPanel count={2}/></div>;
  if(!auth.data)return <Redirect to="/sign-in"/>;
  const submit=async(e:FormEvent)=>{e.preventDefault();setError('');if(newPassword!==confirmPassword){setError('The new passwords do not match.');return;}setBusy(true);try{const response=await fetch('/api/auth/change-password',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({currentPassword,newPassword})});const data=await response.json().catch(()=>null);if(!response.ok)throw new Error(data?.error??'Unable to update your password.');qc.setQueryData(authSessionQueryKey,data as AuthSession);setLocation('/dashboard');}catch(e){setError(e instanceof Error?e.message:'Unable to update your password.');}finally{setBusy(false);}};
  return <div className="request-shell" style={{display:'grid',placeItems:'center'}}><section className="panel request-card" style={{width:'min(100%,460px)',margin:'auto'}}><div style={{marginBottom:14}}><UserChip name={auth.data.employee.fullName} role={auth.data.employee.role}/></div><h1 className="page-title" style={{fontSize:25}}>Choose a new password</h1><p className="page-subtitle" style={{marginBottom:20}}>{auth.data.mustChangePassword?'This temporary password can only be used once. Set a new password to continue.':'Update your account password.'}</p><form onSubmit={submit}><div className="field"><label htmlFor="current-password">Current password</label><input id="current-password" className="input" type="password" value={currentPassword} onChange={e=>setCurrentPassword(e.target.value)} required autoComplete="current-password"/></div><div className="field" style={{marginTop:14}}><label htmlFor="new-password">New password</label><input id="new-password" className="input" type="password" value={newPassword} onChange={e=>setNewPassword(e.target.value)} minLength={12} maxLength={128} required autoComplete="new-password"/><small>Use at least 12 characters.</small></div><div className="field" style={{marginTop:14}}><label htmlFor="confirm-password">Confirm new password</label><input id="confirm-password" className="input" type="password" value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)} minLength={12} maxLength={128} required autoComplete="new-password"/></div>{error&&<div className="alert-box" role="alert" style={{marginTop:14}}><AlertTriangle size={16}/>{error}</div>}<button className="button primary" style={{width:'100%',justifyContent:'center',marginTop:18}} disabled={busy}>{busy?'Saving…':'Save new password'}</button></form></section></div>;
}

function PublicDashboardRedirect(){const auth=useAuthSession();if(auth.isLoading)return <div className="request-shell"><LoadingPanel/></div>;return auth.data?<Redirect to={auth.data.mustChangePassword?'/change-password':'/dashboard'}/>:<PublicHome/>;}
function Protected({children}:{children:ReactNode}){const auth=useAuthSession();if(auth.isLoading)return <div className="page-wrap"><LoadingPanel/></div>;if(auth.isError)return <div className="page-wrap"><ErrorPanel retry={()=>void auth.refetch()}/></div>;if(!auth.data)return <Redirect to="/sign-in"/>;if(auth.data.mustChangePassword)return <Redirect to="/change-password"/>;return <>{children}</>;}
function Shell({children}:{children:ReactNode}) {
  const {employee,region,setRegion}=useApp(); const [loc,setLocation]=useLocation(); const qc=useQueryClient();
  const signOut=async()=>{try{await fetch('/api/auth/logout',{method:'POST',credentials:'same-origin'});}finally{qc.clear();setLocation('/');}};
  return <div className="app-frame"><aside className="sidebar"><Link href={employee.role==='Technician'?'/job-cards':'/dashboard'} className="brand-lockup" style={{textDecoration:'none',color:'inherit'}}><span className="brand-mark">M</span><span><span className="brand-title">MPS — TD</span><small className="brand-sub">MAINTENANCE OPERATIONS</small></span></Link><nav>{links.filter(l=>l.href!='/admin/employees'||employee.role==='Admin').filter(l=>!(employee.role==='Technician'&&l.href!='/job-cards')).filter(l=>!(employee.role==='Storekeeper'&&['/requests','/job-cards','/reports','/admin/employees'].includes(l.href))).filter(l=>!(employee.role==='Supervisor'&&l.href==='/admin/employees')).filter(l=>!(employee.role==='Manager'&&['/storekeeper','/admin/employees'].includes(l.href))).map(l=><span key={l.href}>{l.group&&<div className="nav-caption">{l.group}</div>}<Link href={l.href} className={`nav-link ${loc===l.href?'active':''}`} title={l.label} data-testid={`link-${l.label.toLowerCase().replaceAll(' ','-')}`}><l.icon/><span>{l.label}</span></Link></span>)}</nav><div className="sidebar-foot">OPS SYSTEM / 01<br/><span style={{color:'#edb85e'}}>●</span> Connected · secure session</div></aside>
     <div className="main-area"><header className="topbar"><div className="top-left"><span className="crumb">MPS /</span><span style={{fontSize:13,fontWeight:700,color:'#30494c'}}>{links.find(l=>l.href===loc)?.label??'Workspace'}</span></div><div className="top-actions">{employee.regions.length>1&&<select className="top-region" value={region} onChange={e=>setRegion(e.target.value)} aria-label="Active region" data-testid="select-region">{employee.regions.map(r=><option key={r} value={r}>{r}</option>)}</select>}<UserChip name={employee.fullName} role={employee.role}/><button className="button ghost small" onClick={()=>void signOut()} title="Sign out" data-testid="button-sign-out"><LogOut size={16}/></button></div></header>{children}</div></div>;
}
function Workspace(){const me=useGetCurrentEmployee({query:{queryKey:getGetCurrentEmployeeQueryKey()}});const [region,setRegion]=useState('');const employee=me.data;
  useEffect(()=>{if(employee&&!region)setRegion(employee.region);},[employee,region]);
  if(me.isLoading)return <div className="page-wrap"><LoadingPanel/></div>;
  if(me.isError)return <div className="page-wrap"><ErrorPanel retry={()=>void me.refetch()}/></div>;
  if(!employee)return <div className="page-wrap"><Empty title="Employee profile unavailable" body="Your account is not linked to an MPS employee profile. Contact your administrator."/></div>;
  return <AppContext.Provider value={{employee,region:region||employee.region,setRegion}}><Shell><Switch>
    <Route path="/dashboard"><Protected><RoleGate roles={['Admin','Supervisor','Storekeeper','Technician','Manager']}><Dashboard/></RoleGate></Protected></Route>
    <Route path="/inventory"><Protected><RoleGate roles={['Admin','Supervisor','Storekeeper','Manager']}><Inventory/></RoleGate></Protected></Route>
    <Route path="/storekeeper"><Protected><RoleGate roles={['Storekeeper']}><Storekeeper/></RoleGate></Protected></Route>
    <Route path="/requests"><Protected><RoleGate roles={['Admin','Supervisor','Manager']}><Requests/></RoleGate></Protected></Route>
    <Route path="/job-cards"><Protected><RoleGate roles={['Admin','Supervisor','Technician','Manager']}><Jobs/></RoleGate></Protected></Route>
    <Route path="/reports"><Protected><RoleGate roles={['Admin','Supervisor','Manager']}><Reports/></RoleGate></Protected></Route>
    <Route path="/admin/employees"><Protected><RoleGate roles={['Admin']}><Employees/></RoleGate></Protected></Route>
    <Route><Protected><Dashboard/></Protected></Route>
  </Switch></Shell></AppContext.Provider>;
}

function Dashboard(){const {employee,region}=useApp();const q=useGetMpsDashboard({query:{queryKey:getGetMpsDashboardQueryKey(),enabled:employee.role!=='Technician'}});const s=q.data;const recent=s?.recentRequests??[];if(employee.role==='Technician')return <Redirect to="/job-cards"/>;
  if(q.isLoading)return <div className="page-wrap"><LoadingPanel/></div>;if(q.isError)return <div className="page-wrap"><ErrorPanel retry={()=>void q.refetch()}/></div>;
  return <main className="page-wrap"><PageHeading eyebrow={`${region||employee.region} REGION / LIVE OVERVIEW`} title="Operations at a glance" subtitle={`Good day, ${employee.fullName.split(' ')[0]}. Here’s the current maintenance picture.`} action={<span className="badge"><Activity size={12}/> Live operations</span>}/>
    <section className="stat-grid">{([{label:'Open requests',value:s?.openRequests??0,Icon:ClipboardList,note:'Awaiting team action'},{label:'Active job cards',value:s?.activeJobs??0,Icon:Wrench,note:'Work in progress'},{label:'Pending material',value:s?.pendingMaterial??0,Icon:Boxes,note:'Jobs waiting on stock'},{label:'Completed this month',value:s?.completedThisMonth??0,Icon:Check,note:'Repairs closed'}]).map(({label,value,Icon,note})=><article key={label} className="panel stat-card"><Icon className="stat-icon"/><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-note">{note}</div></article>)}</section>
    <div className="content-grid"><section className="panel"><div className="panel-head"><h2 className="panel-title">Latest maintenance requests</h2><Link href="/requests" className="button ghost small">All requests <ArrowRight size={13}/></Link></div>{recent.length?<Table headers={['Request','Location','Reported','Status']}>{recent.slice(0,6).map((r:MaintenanceRequest)=><tr key={r.requestId}><td><b>{r.requestId}</b><div style={{color:'#85918a',fontSize:10,marginTop:4}}>{r.employeeName}</div></td><td>{r.locationName}</td><td>{new Date(r.createdAt).toLocaleDateString()}</td><td><Badge text={r.status}/></td></tr>)}</Table>:<Empty title="No recent requests" body="New maintenance requests will appear here."/>}</section>
      <div style={{display:'grid',gap:15}}><section className="panel"><div className="panel-head"><h2 className="panel-title">Work status</h2><span className="eyebrow">JOB CARDS</span></div><div className="panel-content">{s?.jobStatusBreakdown?.length?s.jobStatusBreakdown.map((b,index)=>{const max=Math.max(...s.jobStatusBreakdown.map(x=>x.count),1);return <div key={b.status} style={{marginBottom:15}}><div style={{display:'flex',justifyContent:'space-between',fontSize:11,color:'#526660',marginBottom:6}}><span>{b.status}</span><b>{b.count}</b></div><div style={{height:5,borderRadius:5,background:'#ece9df'}}><div style={{height:'100%',width:`${b.count/max*100}%`,borderRadius:5,background:index===0?'#52796d':index===1?'#d7a94c':'#688790'}}/></div></div>}):<div className="stat-note">No job status data yet.</div>}</div></section>
      <section className="panel" style={{padding:18,display:'flex',gap:13,alignItems:'center'}}><div className="empty-icon" style={{margin:0,flexShrink:0}}><Package size={19}/></div><div><div className="stat-label">Warehouse value</div><div className="font-display" style={{fontWeight:800,fontSize:20,color:'#294249',marginTop:4}}>SAR {(s?.stockValueSar??0).toLocaleString()}</div><div className="stat-note">{s?.lowStockItems??0} items below minimum stock</div></div></section></div></div>
  </main>;
}

function Inventory(){const {employee,region}=useApp();const canEdit=employee.role==='Admin'||employee.role==='Storekeeper';const q=useListItems({region},{query:{queryKey:getListItemsQueryKey({region})}});const [query,setQuery]=useState('');const [edit,setEdit]=useState<InventoryItem|null>(null);const [open,setOpen]=useState(false);const create=useCreateItem();const update=useUpdateItem();const qc=useQueryClient();const items=q.data??[];const filtered=items.filter(i=>`${i.itemCode} ${i.itemName} ${i.binLocation??''}`.toLowerCase().includes(query.toLowerCase()));
   const save=async(e:FormEvent)=>{e.preventDefault();const f=new FormData(e.currentTarget as HTMLFormElement);const common={itemName:String(f.get('itemName')),description:String(f.get('description')),unitOfMeasure:String(f.get('unitOfMeasure')),minStockLevel:Number(f.get('minStockLevel')),unitCost:Number(f.get('unitCost')||0),binLocation:String(f.get('binLocation')),barcode:String(f.get('barcode'))};try{if(edit)await update.mutateAsync({itemCode:edit.itemCode,data:common});else await create.mutateAsync({data:{...common,itemCode:String(f.get('itemCode'))}});await qc.invalidateQueries({queryKey:getListItemsQueryKey()});setOpen(false);setEdit(null);}catch{}};
  return <main className="page-wrap"><PageHeading eyebrow="WAREHOUSE / CATALOG" title="Inventory" subtitle={`Stock on hand in ${region}, item value, and procurement history.${canEdit?'':' View only.'}`} action={canEdit?<button className="button primary" onClick={()=>{setEdit(null);setOpen(true)}} data-testid="button-add-item"><Plus size={15}/> Add item</button>:undefined}/>
    <div className="stat-grid" style={{gridTemplateColumns:'repeat(3,minmax(0,1fr))'}}><div className="panel stat-card"><Boxes className="stat-icon"/><div className="stat-label">Catalog items</div><div className="stat-value">{items.length}</div></div><div className="panel stat-card"><AlertTriangle className="stat-icon"/><div className="stat-label">Below minimum</div><div className="stat-value">{items.filter(i=>i.currentStock<i.minStockLevel).length}</div></div><div className="panel stat-card"><BarChart3 className="stat-icon"/><div className="stat-label">Stock valuation</div><div className="stat-value" style={{fontSize:23}}>SAR {items.reduce((sum,i)=>sum+i.valueSar,0).toLocaleString()}</div></div></div>
     <section className="panel"><div className="panel-head"><h2 className="panel-title">Item catalog <span className="eyebrow">· {region}</span></h2><SearchBox value={query} onChange={setQuery} placeholder="Search code, item or bin"/></div>{q.isLoading?<div className="panel-content"><LoadingPanel/></div>:q.isError?<div className="panel-content"><ErrorPanel retry={()=>void q.refetch()}/></div>:filtered.length?<Table headers={['Item code','Description','On hand','Min. level','Unit cost','Value · SAR','Bin','Barcode / QR','']}>{filtered.map(i=><tr key={i.itemCode}><td className="font-mono" style={{fontSize:11}}>{i.itemCode}</td><td><b>{i.itemName}</b><div style={{fontSize:10,color:'#84918a',marginTop:3}}>{i.unitOfMeasure} · {i.description}</div></td><td><b>{i.currentStock}</b> {i.unitOfMeasure}</td><td>{i.minStockLevel}</td><td>{i.unitCost?.toLocaleString()??'—'}</td><td>{i.valueSar.toLocaleString()}</td><td>{i.binLocation??'—'}</td><td><details className="qr-details"><summary className="button outline small">Show QR</summary><div className="qr-pop"><QRCodeSVG value={i.barcode||i.itemCode} size={84}/><small>{i.barcode||i.itemCode}</small></div></details></td><td>{canEdit&&<button className="button outline small" onClick={()=>{setEdit(i);setOpen(true)}}>Edit</button>}</td></tr>)}</Table>:<Empty title="No inventory matches" body="Try another item code or search term."/>}</section>
     {open&&<Modal title={edit?'Edit catalog details':'Quick add inventory item'} close={()=>setOpen(false)}><form onSubmit={save}><div className="field-grid">{!edit&&<div className="field"><label>Item code</label><input className="input" name="itemCode" required/></div>}<div className="field"><label>Item name</label><input className="input" name="itemName" defaultValue={edit?.itemName} required/></div><div className="field"><label>Unit of measure</label><input className="input" name="unitOfMeasure" defaultValue={edit?.unitOfMeasure} required/></div><div className="field"><label>Minimum stock level</label><input className="input" type="number" min="0" name="minStockLevel" defaultValue={edit?.minStockLevel??0}/></div><div className="field"><label>Unit cost · SAR</label><input className="input" type="number" min="0" step="0.01" name="unitCost" defaultValue={edit?.unitCost??0}/></div><div className="field"><label>Bin location</label><input className="input" name="binLocation" defaultValue={edit?.binLocation??''}/></div><div className="field"><label>Barcode / QR value</label><input className="input" name="barcode" defaultValue={edit?.barcode??''}/></div><div className="field"><label>Description</label><input className="input" name="description" defaultValue={edit?.description??''}/></div></div><div style={{display:'flex',justifyContent:'flex-end',gap:8,marginTop:20}}><button type="button" className="button outline" onClick={()=>setOpen(false)}>Cancel</button><button className="button primary" disabled={create.isPending||update.isPending}>{create.isPending||update.isPending?'Saving…':'Save item'}</button></div></form></Modal>}
  </main>;
}
function Modal({title,children,close}:{title:string;children:ReactNode;close:()=>void}){return <div role="dialog" aria-modal="true" style={{position:'fixed',inset:0,zIndex:20,display:'grid',placeItems:'center',padding:16,background:'#172c2fc0'}} onMouseDown={e=>{if(e.target===e.currentTarget)close()}}><section className="panel" style={{width:'min(620px,100%)',maxHeight:'90dvh',overflow:'auto',padding:22}}><div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}><h2 className="panel-title">{title}</h2><button className="button ghost small" onClick={close} aria-label="Close"><X size={16}/></button></div>{children}</section></div>}

type DeskMode = 'OUT' | 'IN' | 'RETURN' | 'TRANSFER';
const DESK_MODES: { mode: DeskMode; label: string; hint: string }[] = [
  { mode: 'OUT', label: 'Issue', hint: 'Give materials to a technician for an active job card.' },
  { mode: 'IN', label: 'Receive', hint: 'Book new stock arriving from a supplier (purchase order or cash purchase).' },
  { mode: 'RETURN', label: 'Return', hint: 'A technician gives unused materials back to this warehouse.' },
  { mode: 'TRANSFER', label: 'Transfer', hint: 'Move stock from this warehouse to another warehouse (region).' },
];
function movementLabel(t: { transactionType: string; purchaseType?: string | null }) {
  if (t.transactionType === 'OUT') return 'ISSUE';
  if (t.transactionType === 'TRANSFER') return 'TRANSFER';
  return t.purchaseType === 'Return' ? 'RETURN' : 'RECEIVE';
}

function Storekeeper(){
  const {employee,region}=useApp();const qc=useQueryClient();
  const tx=useListTransactions({region},{query:{queryKey:getListTransactionsQueryKey({region})}});
  const itemsQ=useListItems({region},{query:{queryKey:getListItemsQueryKey({region})}});
  const empQ=useListEmployees({query:{queryKey:getListEmployeesQueryKey()}});
  const regionsQ=useListRegions({query:{queryKey:getListRegionsQueryKey()}});
  const create=useCreateTransaction();
  const [mode,setMode]=useState<DeskMode>('OUT');const [receiptType,setReceiptType]=useState<'PO'|'Cash'>('PO');
  const [term,setTerm]=useState('');const [itemCode,setItemCode]=useState('');const [employeeId,setEmployeeId]=useState('');const [jobCardId,setJobCardId]=useState('');
  const [quantity,setQuantity]=useState('1');const [ref,setRef]=useState('');const [supplier,setSupplier]=useState('');const [unitCost,setUnitCost]=useState('');
  const [invoiceDate,setInvoiceDate]=useState(new Date().toISOString().slice(0,10));const [toRegion,setToRegion]=useState('');
  const [error,setError]=useState('');const [notice,setNotice]=useState('');
  const items=itemsQ.data??[];
  const technicians=(empQ.data??[]).filter(e=>e.role==='Technician');
  const matches=technicians.filter(e=>`${e.employeeId} ${e.fullName}`.toLowerCase().includes(term.trim().toLowerCase()));
  const selected=items.find(i=>i.itemCode===itemCode);
  const destinations=(regionsQ.data??[]).filter(r=>r!==region);
  const needsTechnician=mode==='OUT'||mode==='RETURN';
  const consumesStock=mode==='OUT'||mode==='TRANSFER';
  const qty=Number(quantity);
  const insufficient=consumesStock&&!!selected&&Number.isFinite(qty)&&qty>selected.currentStock;
  const jobs=useGetEmployeeActiveJobs(employeeId,{query:{queryKey:getGetEmployeeActiveJobsQueryKey(employeeId),enabled:needsTechnician&&!!employeeId}});
  const current=DESK_MODES.find(m=>m.mode===mode)!;
  const choose=(next:DeskMode)=>{setMode(next);setError('');setNotice('');setJobCardId('');setRef('');};
  const submit=async(e:FormEvent)=>{
    e.preventDefault();setError('');setNotice('');
    if(!itemCode){setError('Choose an inventory item.');return;}
    if(!Number.isInteger(qty)||qty<1){setError('Enter a whole quantity of 1 or more.');return;}
    if(needsTechnician&&!employeeId){setError('Choose the technician.');return;}
    if(mode==='OUT'&&!jobCardId){setError('Choose the active job card this issue is for.');return;}
    if(mode==='RETURN'&&!jobCardId&&!ref.trim()){setError('Choose a job card or enter a return reference.');return;}
    if(mode==='TRANSFER'&&!toRegion){setError('Choose the destination warehouse.');return;}
    if(insufficient){setError(`Only ${selected?.currentStock} ${selected?.unitOfMeasure} available in ${region}.`);return;}
    try{
      const saved=await create.mutateAsync({data:{
        transactionType:mode==='OUT'?'OUT':mode==='TRANSFER'?'TRANSFER':'IN',
        itemCode,quantity:qty,
        employeeId:needsTechnician?employeeId:employee.employeeId,
        jobCardId:needsTechnician&&jobCardId?jobCardId:undefined,
        referenceNo:ref.trim()||undefined,
        supplierName:mode==='IN'?supplier.trim()||undefined:undefined,
        purchaseType:mode==='IN'?receiptType:mode==='RETURN'?'Return':undefined,
        unitCost:mode==='IN'&&unitCost?Number(unitCost):undefined,
        invoiceDate:mode==='IN'?invoiceDate:undefined,
        region,toRegion:mode==='TRANSFER'?toRegion:undefined,
      }});
      setNotice(mode==='TRANSFER'?`Transferred ${qty} × ${saved.itemName} from ${region} to ${toRegion}.`:mode==='OUT'?`Issued ${qty} × ${saved.itemName} to ${saved.employeeName}.`:mode==='RETURN'?`Returned ${qty} × ${saved.itemName} from ${saved.employeeName} to ${region}.`:`Received ${qty} × ${saved.itemName} into ${region}.`);
      await Promise.all([qc.invalidateQueries({queryKey:getListTransactionsQueryKey()}),qc.invalidateQueries({queryKey:getListItemsQueryKey()}),qc.invalidateQueries({queryKey:getGetMpsDashboardQueryKey()})]);
      setQuantity('1');setRef('');setSupplier('');setUnitCost('');setJobCardId('');
    }catch(e2){setError(apiMessage(e2,'The transaction could not be recorded.'));}
  };
  return <main className="page-wrap"><PageHeading eyebrow="WAREHOUSE / MATERIAL CONTROL" title="Warehouse desk" subtitle="Record receipts, issues, returns, and transfers between warehouses."/>
  <div className="content-grid" style={{gridTemplateColumns:'minmax(0,1fr) minmax(300px,.82fr)'}}><section className="panel"><div className="panel-head"><h2 className="panel-title">Record movement</h2><span className="badge blue">{region}</span></div><div className="panel-content">
    <div className="mode-tabs" role="tablist" aria-label="Movement type" style={{marginBottom:10}}>{DESK_MODES.map(m=><button type="button" role="tab" aria-selected={mode===m.mode} key={m.mode} className={`button small ${mode===m.mode?'primary':'outline'}`} onClick={()=>choose(m.mode)} data-testid={`button-mode-${m.mode.toLowerCase()}`}>{m.mode==='OUT'?<ArrowUpFromLine size={14}/>:m.mode==='IN'?<ArrowDownToLine size={14}/>:m.mode==='RETURN'?<RefreshCw size={14}/>:<ArrowLeftRight size={14}/>} {m.label}</button>)}</div>
    <p className="stat-note" style={{margin:'0 0 16px'}}>{current.hint}</p>
    <form onSubmit={submit}><div className="field-grid"><div className="field"><label>Item</label><select className="select" value={itemCode} onChange={e=>setItemCode(e.target.value)} required><option value="">Choose catalog item</option>{items.map(i=><option key={i.itemCode} value={i.itemCode}>{i.itemCode} — {i.itemName} · {i.currentStock} {i.unitOfMeasure}</option>)}</select></div><div className="field"><label>Quantity</label><input className="input" type="number" min="1" step="1" value={quantity} onChange={e=>setQuantity(e.target.value)} required/></div>
      {needsTechnician&&<><div className="field"><label>Find technician by ID or name</label><input className="input" value={term} onChange={e=>setTerm(e.target.value)} placeholder="Employee ID or full name"/></div><div className="field"><label>{mode==='OUT'?'Technician receiving the materials':'Technician returning the materials'}</label><select className="select" value={employeeId} onChange={e=>{setEmployeeId(e.target.value);setJobCardId('');}} required><option value="">Choose technician</option>{matches.map(t=><option key={t.employeeId} value={t.employeeId}>{t.employeeId} · {t.fullName}</option>)}</select></div>
        <div className="field"><label>{mode==='OUT'?'Active job card':'Job card (optional)'}</label><select className="select" value={jobCardId} onChange={e=>setJobCardId(e.target.value)} required={mode==='OUT'} disabled={!employeeId}><option value="">{employeeId?(mode==='OUT'?'Choose active job card':'No job card'):'Choose a technician first'}</option>{(jobs.data??[]).map(j=><option key={j.jobCardId} value={j.jobCardId}>{j.jobCardId} · {j.locationName}</option>)}</select></div></>}
      {mode==='RETURN'&&<div className="field"><label>Return reference</label><input className="input" value={ref} onChange={e=>setRef(e.target.value)} placeholder="Defaults to the job card number"/></div>}
      {mode==='IN'&&<><div className="field"><label>Receipt type</label><select className="select" value={receiptType} onChange={e=>setReceiptType(e.target.value as 'PO'|'Cash')}><option value="PO">Purchase order</option><option value="Cash">Cash purchase</option></select></div><div className="field"><label>Supplier</label><input className="input" value={supplier} onChange={e=>setSupplier(e.target.value)} required/></div><div className="field"><label>Supplier invoice / PO #</label><input className="input" value={ref} onChange={e=>setRef(e.target.value)} required/></div><div className="field"><label>Invoice date</label><input className="input" type="date" value={invoiceDate} onChange={e=>setInvoiceDate(e.target.value)} required/></div><div className="field"><label>Unit cost · SAR</label><input className="input" type="number" min="0" step="0.01" value={unitCost} onChange={e=>setUnitCost(e.target.value)} placeholder={selected?.unitCost?.toString()??'0'}/></div></>}
      {mode==='TRANSFER'&&<><div className="field"><label>From warehouse</label><input className="input" value={region} readOnly/></div><div className="field"><label>To warehouse</label><select className="select" value={toRegion} onChange={e=>setToRegion(e.target.value)} required><option value="">Choose destination</option>{destinations.map(r=><option key={r} value={r}>{r}</option>)}</select></div><div className="field"><label>Transfer reference (optional)</label><input className="input" value={ref} onChange={e=>setRef(e.target.value)} placeholder="e.g. transfer note number"/></div></>}
    </div>
    {selected&&<div className="alert-box" style={{marginTop:14}}><Boxes size={16}/><span>Available in {region}: <strong>{selected.currentStock} {selected.unitOfMeasure}</strong> · Stored at {selected.binLocation||'unassigned bin'}</span></div>}
    {insufficient&&<div className="alert-box" role="alert" style={{marginTop:10}}><AlertTriangle size={16}/><span>The quantity is more than the stock available in {region}.</span></div>}
    {error&&<div className="alert-box" role="alert" style={{marginTop:10}}><AlertTriangle size={16}/><span>{error}</span></div>}
    {notice&&<div className="alert-box success" style={{marginTop:10}}><Check size={16}/><span>{notice}</span></div>}
    <button className="button primary" style={{marginTop:18}} disabled={create.isPending||insufficient} data-testid="button-confirm-movement">{create.isPending?'Recording…':`Confirm ${current.label.toLowerCase()}`} <Check size={15}/></button></form>
  </div></section><section className="panel"><div className="panel-head"><h2 className="panel-title">Recent ledger</h2><span className="eyebrow">LATEST MOVEMENTS</span></div>{tx.isLoading?<div className="panel-content"><LoadingPanel count={2}/></div>:tx.isError?<div className="panel-content"><ErrorPanel retry={()=>void tx.refetch()}/></div>:tx.data?.length?<Table headers={['Movement','Item','Qty','Employee / route']} minWidth={500}>{tx.data.slice(0,12).map(t=><tr key={t.transactionId}><td><Badge text={movementLabel(t)}/><div style={{fontSize:9,color:'#87918b',marginTop:4}}>{new Date(t.createdAt).toLocaleString()}</div></td><td><b>{t.itemName}</b><div className="font-mono" style={{fontSize:9,color:'#87918b'}}>{t.itemCode}</div></td><td>{t.quantity}</td><td>{t.transactionType==='TRANSFER'?<><b>{t.region} → {t.toRegion}</b><div style={{fontSize:10,color:'#84918a'}}>{t.employeeName}</div></>:t.employeeName}</td></tr>)}</Table>:<Empty title="No stock movements" body="Confirmed movements will appear in this ledger."/>}</section></div>
 </main>;
}

function RequesterApprovals(){
  const qc=useQueryClient();
  const q=useListRequesters({status:'Pending'},{query:{queryKey:getListRequestersQueryKey({status:'Pending'})}});
  const verify=useVerifyRequester();const reject=useRejectRequester();
  const [error,setError]=useState('');const [busyId,setBusyId]=useState('');const [notice,setNotice]=useState('');
  const people=q.data??[];
  const refresh=()=>Promise.all([qc.invalidateQueries({queryKey:getListRequestersQueryKey()}),qc.invalidateQueries({queryKey:getListMaintenanceRequestsQueryKey()}),qc.invalidateQueries({queryKey:getGetMpsDashboardQueryKey()})]);
  const decide=async(person:Requester,action:'verify'|'reject')=>{
    if(action==='reject'&&!window.confirm(`Reject ${person.email}? Their waiting requests will be rejected and they will not be able to send new ones.`))return;
    setError('');setNotice('');setBusyId(person.employeeId);
    try{
      if(action==='verify'){await verify.mutateAsync({employeeId:person.employeeId});setNotice(`${person.email} is verified. Their requests were released to the maintenance team and future requests are accepted directly.`);}
      else{await reject.mutateAsync({employeeId:person.employeeId});setNotice(`${person.email} was rejected.`);}
      await refresh();
    }catch(e){setError(apiMessage(e,'Unable to update this requester.'));}
    finally{setBusyId('');}
  };
  return <section className="panel" style={{marginBottom:16}} data-testid="panel-requester-approvals"><div className="panel-head"><h2 className="panel-title">Email verification</h2><span className={`badge ${people.length?'amber':'gray'}`}>{people.length} waiting</span></div>
    <div className="panel-content" style={{paddingTop:0}}>
      {error&&<div className="alert-box" role="alert" style={{marginBottom:12}}><AlertTriangle size={15}/>{error}</div>}
      {notice&&<div className="alert-box success" style={{marginBottom:12}}><Check size={15}/>{notice}</div>}
      {q.isLoading?<LoadingPanel count={1}/>:q.isError?<ErrorPanel retry={()=>void q.refetch()}/>:people.length?<Table headers={['Requester','Department / region','Waiting request','Registered','']} minWidth={780}>{people.map(p=><tr key={p.employeeId}><td><b>{p.fullName}</b><div style={{fontSize:10,color:'#84918a'}}>{p.email}</div></td><td>{p.department}<div style={{fontSize:10,color:'#84918a'}}>{p.region}</div></td><td style={{whiteSpace:'normal',minWidth:180,maxWidth:260}}><b>{p.waitingRequests}</b> waiting{p.latestDescription&&<div style={{fontSize:10,color:'#84918a'}}>{p.latestLocation} · {p.latestDescription}</div>}</td><td>{new Date(p.createdAt).toLocaleDateString()}</td><td><div className="table-actions"><button className="button primary small" disabled={busyId===p.employeeId} onClick={()=>void decide(p,'verify')}><Check size={12}/> Verify email</button><button className="button outline small danger" disabled={busyId===p.employeeId} onClick={()=>void decide(p,'reject')}>Reject</button></div></td></tr>)}</Table>:<div className="stat-note">No requesters are waiting for verification. First-time emails appear here with their request.</div>}
    </div></section>;
}

function Requests(){const {region,employee}=useApp();const qc=useQueryClient();const q=useListMaintenanceRequests({region},{query:{queryKey:getListMaintenanceRequestsQueryKey({region})}});const jobsQ=useListJobCards({region},{query:{queryKey:getListJobCardsQueryKey({region})}});const create=useCreateJobCard();const updateRequest=useUpdateMaintenanceRequest();const [filter,setFilter]=useState('');const [search,setSearch]=useState('');const [request,setRequest]=useState<MaintenanceRequest|null>(null);const [team,setTeam]=useState('');const [techs,setTechs]=useState<string[]>([]);const [actionError,setActionError]=useState('');const employeesQ=useListEmployees({query:{queryKey:getListEmployeesQueryKey(),enabled:employee.role==='Supervisor'}});const requests=q.data??[];const list=useMemo(()=>requests.filter(r=>(!filter||r.status===filter)&&`${r.requestId} ${r.employeeName} ${r.locationName} ${r.description}`.toLowerCase().includes(search.toLowerCase())),[requests,filter,search]);const canAssign=employee.role==='Supervisor';const technicians=(employeesQ.data??[]).filter(e=>e.role==='Technician');
 const assign=async(e:FormEvent)=>{e.preventDefault();if(!request)return;setActionError('');try{await create.mutateAsync({data:{requestId:request.requestId,teamName:team,technicianIds:techs}});await Promise.all([qc.invalidateQueries({queryKey:getListMaintenanceRequestsQueryKey({region})}),qc.invalidateQueries({queryKey:getListJobCardsQueryKey({region})})]);setRequest(null);}catch(error){setActionError(apiMessage(error,'Unable to create the job card.'));setRequest(null);}};
 const review=async(r:MaintenanceRequest,status:'Approved'|'Rejected')=>{if(status==='Rejected'&&!window.confirm(`Reject request ${r.requestId}?`))return;setActionError('');try{await updateRequest.mutateAsync({requestId:r.requestId,data:{status}});await Promise.all([qc.invalidateQueries({queryKey:getListMaintenanceRequestsQueryKey({region})}),qc.invalidateQueries({queryKey:getGetMpsDashboardQueryKey()})]);}catch(error){setActionError(apiMessage(error,'Unable to update this request.'));}};
 return <main className="page-wrap"><PageHeading eyebrow="OPERATIONS / INTAKE" title="Maintenance requests" subtitle="Review incoming work and connect requests to assigned job cards." action={<span className="badge blue">{requests.length} records</span>}/>
 {employee.role==='Admin'&&<RequesterApprovals/>}
 {actionError&&<div className="alert-box" role="alert" style={{marginBottom:14}}><AlertTriangle size={15}/>{actionError}</div>}
 <section className="panel"><div className="panel-head"><div className="top-actions"><SearchBox value={search} onChange={setSearch} placeholder="Search request, person, location"/><select className="select" style={{width:160}} value={filter} onChange={e=>setFilter(e.target.value)} aria-label="Filter status"><option value="">All statuses</option>{Array.from(new Set(requests.map(r=>r.status))).map(s=><option key={s}>{s}</option>)}</select></div><button className="button outline small" onClick={()=>{void q.refetch();void jobsQ.refetch()}}><RefreshCw size={13}/> Refresh</button></div>
 {q.isLoading?<div className="panel-content"><LoadingPanel/></div>:q.isError?<div className="panel-content"><ErrorPanel retry={()=>void q.refetch()}/></div>:list.length?<Table headers={['Request','Reported by','Location / region','Description','Status','Job cards','Actions']} minWidth={950}>{list.map(r=><tr key={r.requestId}><td className="font-mono">{r.requestId}</td><td><b>{r.employeeName}</b><div style={{fontSize:10,color:'#84918a'}}>{r.department}</div></td><td>{r.locationName}<div style={{fontSize:10,color:'#84918a'}}>{r.region}</div></td><td style={{whiteSpace:'normal',minWidth:190,maxWidth:270}}>{r.description.slice(0,96)}{r.description.length>96?'…':''}</td><td><Badge text={r.status}/></td><td>{r.jobCardIds.length?r.jobCardIds.map(id=><span key={id} className="font-mono" style={{fontSize:10,display:'block'}}>{id}</span>):'—'}</td><td><div style={{display:'flex',gap:5,alignItems:'center'}}>{r.status==='Pending Verification'&&<span style={{fontSize:10,color:'#8a662e'}}>Awaiting email verification</span>}{canAssign&&r.status.toLowerCase()!=='approved'&&r.status.toLowerCase()!=='rejected'&&<><button className="button outline small" disabled={updateRequest.isPending} onClick={()=>void review(r,'Approved')}>Approve</button><button className="button outline small" disabled={updateRequest.isPending} onClick={()=>void review(r,'Rejected')}>Reject</button></>}{canAssign&&<button className="button primary small" onClick={()=>{setRequest(r);setTeam('');setTechs([])}}><Plus size={12}/> Job card</button>}</div></td></tr>)}</Table>:<Empty title="No requests found" body="New requests will appear here once submitted."/>}</section>
 {canAssign&&request&&<Modal title={`Create job card · ${request.requestId}`} close={()=>setRequest(null)}><div className="alert-box" style={{marginBottom:16}}><MapPin size={15}/>{request.locationName} · {request.description}</div><form onSubmit={assign}><div className="field"><label>Team name</label><input className="input" value={team} onChange={e=>setTeam(e.target.value)} required placeholder="e.g. Electrical response"/></div><div className="field" style={{marginTop:14}}><label>Assign technicians</label><div style={{display:'grid',gap:7,maxHeight:180,overflow:'auto',padding:8,border:'1px solid #e4dfd4',borderRadius:8}}>{technicians.map(t=><label key={t.employeeId} style={{display:'flex',alignItems:'center',gap:8,fontSize:12}}><input type="checkbox" checked={techs.includes(t.employeeId)} onChange={e=>setTechs(e.target.checked?[...techs,t.employeeId]:techs.filter(id=>id!==t.employeeId))}/>{t.fullName} <span style={{color:'#82908a'}}>· {t.employeeId}</span></label>)}</div></div><div style={{display:'flex',justifyContent:'flex-end',gap:8,marginTop:18}}><button type="button" className="button outline" onClick={()=>setRequest(null)}>Cancel</button><button className="button primary" disabled={!team||create.isPending}>{create.isPending?'Assigning…':'Create and assign'}</button></div></form></Modal>}
 </main>;
}

function Jobs(){const {employee,region}=useApp();const qc=useQueryClient();const q=useListJobCards({region},{query:{queryKey:getListJobCardsQueryKey({region})}});const empQ=useListEmployees({query:{queryKey:getListEmployeesQueryKey(),enabled:employee.role==='Supervisor'}});const update=useUpdateJobCard();const upload=useRequestMpsUploadUrl();const [search,setSearch]=useState('');const [editing,setEditing]=useState<JobCard|null>(null);const [term,setTerm]=useState('');
 const all=q.data??[];const items=all.filter(j=>(employee.role!=='Technician'||j.technicianIds.includes(employee.employeeId))&&`${j.jobCardId} ${j.requestId} ${j.locationName} ${j.teamName}`.toLowerCase().includes(search.toLowerCase()));const isSupervisor=employee.role==='Supervisor';const techs=(empQ.data??[]).filter(e=>e.role==='Technician');const selectedTechs=editing?.technicianIds??[];
 const save=async(e:FormEvent)=>{e.preventDefault();if(!editing)return;const f=new FormData(e.currentTarget as HTMLFormElement);try{await update.mutateAsync({jobCardId:editing.jobCardId,data:{teamName:String(f.get('teamName')),repairReport:String(f.get('repairReport')),jobStatus:String(f.get('jobStatus')),technicianIds:selectedTechs,attachments:editing.attachments}});await qc.invalidateQueries({queryKey:getListJobCardsQueryKey({region})});setEditing(null);}catch{}};
 const media=async(e:React.ChangeEvent<HTMLInputElement>)=>{if(!editing||!e.target.files)return;const files=Array.from(e.target.files).slice(0,Math.max(0,3-editing.attachments.length));let attachments=[...editing.attachments];for(const file of files){try{const data=await upload.mutateAsync({data:{name:file.name,size:file.size,contentType:file.type,purpose:'job-card'}});const r=await fetch(data.uploadURL,{method:'PUT',headers:{'Content-Type':file.type},body:file});if(!r.ok)throw new Error();attachments.push({path:data.objectPath,name:file.name,type:file.type});}catch{}}setEditing({...editing,attachments});};
  const escapeHtml=(value:string)=>value.replace(/[&<>"']/g,character=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[character]??character));
  const downloadPdf=(job:JobCard)=>{const html=`<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(job.jobCardId)}</title><style>body{font:14px Arial;color:#263b3f;padding:40px}h1{color:#29464c;border-bottom:3px solid #edb85e;padding-bottom:15px}small{color:#73817c}section{margin:24px 0;line-height:1.7;white-space:pre-wrap}@media print{body{padding:10mm}}</style></head><body><h1>MPS — TD · Job card</h1><small>${escapeHtml(job.jobCardId)} · ${escapeHtml(job.jobStatus)}</small><section><b>Location:</b> ${escapeHtml(job.locationName)}<br><b>Team:</b> ${escapeHtml(job.teamName)}<br><b>Technicians:</b> ${escapeHtml(job.technicianNames.join(', '))}</section><section><h3>Work requested</h3>${escapeHtml(job.description)}</section><section><h3>Repair report</h3>${escapeHtml(job.repairReport||'Not yet recorded')}</section><script>window.onload=()=>window.print()</script></body></html>`;const w=window.open('','_blank');if(w){w.document.write(html);w.document.close();}};
  const emailJob=(j:JobCard)=>{const workspaceLink=`${window.location.origin}${basePath}/job-cards?jobCardId=${encodeURIComponent(j.jobCardId)}`;const body=`Job card ${j.jobCardId}\\nLocation: ${j.locationName}\\nTeam: ${j.teamName}\\nTechnicians: ${j.technicianNames.join(', ')}\\nStatus: ${j.jobStatus}\\n\\n${j.description}\\n\\nRepair report: ${j.repairReport||'Pending'}\\n\\nJob card workspace: ${workspaceLink}\\nA printable MPS — TD job card is ready. Attach the PDF downloaded from the job card screen; mailto cannot attach files automatically.`;window.location.href=`mailto:${encodeURIComponent(j.requestorEmail)}?subject=${encodeURIComponent(`MPS — TD ${j.jobCardId}`)}&body=${encodeURIComponent(body)}`;};
  const whatsappJob=(j:JobCard)=>{const text=`MPS — TD ${j.jobCardId}\\n${j.locationName} · ${j.jobStatus}\\nTeam: ${j.teamName}\\n${j.description}`;window.open(`https://wa.me/?text=${encodeURIComponent(text)}`,'_blank','noopener,noreferrer');};
 return <main className="page-wrap"><PageHeading eyebrow="OPERATIONS / FIELD EXECUTION" title={employee.role==='Technician'?'My assigned work':'Job cards'} subtitle={employee.role==='Technician'?'Work assigned to you, with current status and repair context.':'Coordinate teams, technicians, work narratives, and close-out.'}/><section className="panel"><div className="panel-head"><SearchBox value={search} onChange={setSearch} placeholder="Search job card, request or location"/><button className="button outline small" onClick={()=>void q.refetch()}><RefreshCw size={13}/> Refresh</button></div>
  {q.isLoading?<div className="panel-content"><LoadingPanel/></div>:q.isError?<div className="panel-content"><ErrorPanel retry={()=>void q.refetch()}/></div>:items.length?<Table headers={['Job card','Location','Team / technicians','Status','Opened','']} minWidth={780}>{items.map(j=><tr key={j.jobCardId}><td><b className="font-mono">{j.jobCardId}</b><div style={{fontSize:10,color:'#87918b',marginTop:4}}>Request {j.requestId}</div></td><td>{j.locationName}</td><td>{j.teamName}<div style={{fontSize:10,color:'#87918b',marginTop:4}}>{j.technicianNames.join(', ')||'No technicians'}</div></td><td><Badge text={j.jobStatus}/></td><td>{new Date(j.createdAt).toLocaleDateString()}</td><td><div style={{display:'flex',gap:5}}><button className="button outline small" onClick={()=>downloadPdf(j)} title="Generate printable job card"><Download size={13}/></button><button className="button outline small" onClick={()=>emailJob(j)} title="Coordinate in Outlook"><Mail size={13}/></button><button className="button outline small" onClick={()=>whatsappJob(j)} title="Coordinate with technicians in WhatsApp"><MessageCircle size={13}/></button>{isSupervisor&&<button className="button primary small" onClick={()=>setEditing(j)}>Edit</button>}</div></td></tr>)}</Table>:<Empty title="No job cards assigned" body="Job cards assigned to this role will appear here."/>}</section>
 {isSupervisor&&editing&&<Modal title={`Edit ${editing.jobCardId}`} close={()=>setEditing(null)}><form onSubmit={save}><div className="field-grid"><div className="field"><label>Team name</label><input name="teamName" className="input" defaultValue={editing.teamName} required/></div><div className="field"><label>Job status</label><select name="jobStatus" className="select" defaultValue={editing.jobStatus}>{['Open','In Progress','Pending Material','Completed / Closed','Cancelled'].map(s=><option key={s}>{s}</option>)}</select></div></div><div className="field" style={{marginTop:14}}><label>Repair narrative</label><textarea name="repairReport" className="textarea" defaultValue={editing.repairReport??''} placeholder="Record diagnosis, work completed, and follow-up actions."/></div><div className="field" style={{marginTop:14}}><label>Assign technicians</label><input className="input" value={term} onChange={e=>setTerm(e.target.value)} placeholder="Search technicians"/><div style={{maxHeight:130,overflow:'auto',padding:8}}>{techs.filter(t=>t.fullName.toLowerCase().includes(term.toLowerCase())).map(t=><label key={t.employeeId} style={{display:'flex',gap:8,padding:5,fontSize:12}}><input type="checkbox" checked={selectedTechs.includes(t.employeeId)} onChange={e=>setEditing({...editing,technicianIds:e.target.checked?[...selectedTechs,t.employeeId]:selectedTechs.filter(x=>x!==t.employeeId),technicianNames:e.target.checked?[...editing.technicianNames,t.fullName]:editing.technicianNames.filter(x=>x!==t.fullName)})}/>{t.fullName}</label>)}</div></div><div className="field" style={{marginTop:12}}><label>Media · {editing.attachments.length}/3</label><input type="file" accept="image/*,video/*" multiple className="input" onChange={e=>void media(e)}/><small>{editing.attachments.map(a=>a.name).join(' · ')}</small></div><div style={{display:'flex',justifyContent:'flex-end',gap:8,marginTop:18}}><button type="button" className="button outline" onClick={()=>setEditing(null)}>Cancel</button><button className="button primary" disabled={update.isPending}>{update.isPending?'Saving…':'Save job card'}</button></div></form></Modal>}
 </main>;
}

function Reports(){const {region}=useApp();const [from,setFrom]=useState('');const [to,setTo]=useState('');const [tech,setTech]=useState('');const employees=useListEmployees({query:{queryKey:getListEmployeesQueryKey()}});const q=useGetMpsReports({region,from:from||undefined,to:to||undefined,technicianId:tech||undefined},{query:{queryKey:getGetMpsReportsQueryKey({region,from:from||undefined,to:to||undefined,technicianId:tech||undefined})}});const reports=q.data;
 const exportData=async(kind:'xlsx'|'pdf')=>{if(!reports)return;if(kind==='pdf'){const lines=[['MPS — TD REPORT',`Region: ${region}`,`Period: ${from||'Start'} – ${to||'Today'}`],['REQUESTS'],...reports.requests.map(r=>[r.requestId,r.employeeName,r.locationName,r.status,r.createdAt]),['TECHNICIAN PERFORMANCE'],...reports.technicianPerformance.map(t=>[t.employeeId,t.fullName,t.assignedJobs,t.completedJobs,t.soloJobs,t.teamJobs]),['INVENTORY LEDGER'],...reports.inventoryLedger.map(t=>[t.transactionId,t.transactionType,t.itemCode,t.quantity,t.employeeName,t.createdAt])];const w=window.open('','_blank');if(w){w.document.write(`<html><head><title>MPS report</title><style>body{font:12px Arial;padding:32px;color:#243d43}h1{color:#29464c}pre{white-space:pre-wrap;line-height:1.7}</style></head><body><h1>MPS — TD · Operations report</h1><pre>${lines.map(a=>a.join('  |  ')).join('\\n')}</pre><script>window.onload=()=>window.print()</script></body></html>`);w.document.close();}return;}const workbook=XLSX.utils.book_new();const requestsSheet=XLSX.utils.json_to_sheet(reports.requests.map(r=>({Request:r.requestId,Employee:r.employeeName,Department:r.department,Region:r.region,Location:r.locationName,Status:r.status,Created:r.createdAt,Description:r.description,JobCards:r.jobCardIds.join(', ')})));const performanceSheet=XLSX.utils.json_to_sheet(reports.technicianPerformance.map(t=>({'Employee ID':t.employeeId,Technician:t.fullName,Assigned:t.assignedJobs,Completed:t.completedJobs,'Solo jobs':t.soloJobs,'Team jobs':t.teamJobs})));const ledgerSheet=XLSX.utils.json_to_sheet(reports.inventoryLedger.map(t=>({'Transaction ID':t.transactionId,Type:t.transactionType,'Item code':t.itemCode,Item:t.itemName,Quantity:t.quantity,Employee:t.employeeName,'Job card':t.jobCardId,Region:t.region,Date:t.createdAt})));const stockSheet=XLSX.utils.json_to_sheet(reports.lowStockItems.map(i=>({'Item code':i.itemCode,Item:i.itemName,'On hand':i.currentStock,'Minimum level':i.minStockLevel,Unit:i.unitOfMeasure,Bin:i.binLocation})));XLSX.utils.book_append_sheet(workbook,requestsSheet,'Requests');XLSX.utils.book_append_sheet(workbook,performanceSheet,'Technician performance');XLSX.utils.book_append_sheet(workbook,ledgerSheet,'Inventory ledger');XLSX.utils.book_append_sheet(workbook,stockSheet,'Low stock');XLSX.writeFile(workbook,'mps-operations-report.xlsx');};
 return <main className="page-wrap"><PageHeading eyebrow="INSIGHTS / EXPORTS" title="Operations reports" subtitle="Filter the record set, then export a field-ready report." action={<span className="badge blue">ENGLISH REPORT</span>}/><section className="panel" style={{marginBottom:16}}><div className="panel-head"><h2 className="panel-title">Report scope</h2><span className="eyebrow">FILTERS</span></div><div className="panel-content"><div className="field-grid" style={{gridTemplateColumns:'repeat(4,minmax(0,1fr))'}}><TextField label="From" type="date" value={from} onChange={setFrom}/><TextField label="To" type="date" value={to} onChange={setTo}/><div className="field"><label>Technician</label><select className="select" value={tech} onChange={e=>setTech(e.target.value)}><option value="">All technicians</option>{(employees.data??[]).filter(e=>e.role==='Technician').map(e=><option value={e.employeeId} key={e.employeeId}>{e.fullName}</option>)}</select></div><div className="field"><label>Region</label><input className="input" value={region} readOnly/></div></div></div></section>
 {q.isLoading?<LoadingPanel/>:q.isError?<ErrorPanel retry={()=>void q.refetch()}/>:reports&&<><div className="stat-grid">{[['Requests',reports.requests.length],['Technicians',reports.technicianPerformance.length],['Ledger movements',reports.inventoryLedger.length],['Low stock',reports.lowStockItems.length]].map(([a,b])=><div className="panel stat-card" key={String(a)}><div className="stat-label">{a}</div><div className="stat-value">{b}</div></div>)}</div><section className="panel" style={{marginBottom:16}}><div className="panel-head"><h2 className="panel-title">Technician performance</h2><div style={{display:'flex',gap:7}}><button className="button outline small" onClick={()=>void exportData('xlsx')}><Download size={13}/> Export XLSX</button><button className="button primary small" onClick={()=>void exportData('pdf')}><FileText size={13}/> Print / PDF</button></div></div>{reports.technicianPerformance.length?<Table headers={['Technician','Employee ID','Assigned','Completed','Solo jobs','Team jobs']}>{reports.technicianPerformance.map(t=><tr key={t.employeeId}><td><b>{t.fullName}</b></td><td className="font-mono">{t.employeeId}</td><td>{t.assignedJobs}</td><td>{t.completedJobs}</td><td>{t.soloJobs}</td><td>{t.teamJobs}</td></tr>)}</Table>:<Empty title="No performance records" body="Records will be available for the selected filters."/>}</section>
 <div className="content-grid"><section className="panel"><div className="panel-head"><h2 className="panel-title">Requests</h2></div>{reports.requests.length?<Table headers={['Request','Employee','Location','Status']}>{reports.requests.slice(0,40).map(r=><tr key={r.requestId}><td className="font-mono">{r.requestId}</td><td>{r.employeeName}</td><td>{r.locationName}</td><td><Badge text={r.status}/></td></tr>)}</Table>:<Empty title="No request data" body="No records in this report scope."/ >}</section><section className="panel"><div className="panel-head"><h2 className="panel-title">Low stock</h2></div>{reports.lowStockItems.length?<Table headers={['Item','On hand','Minimum']} minWidth={350}>{reports.lowStockItems.map(i=><tr key={i.itemCode}><td>{i.itemName}</td><td>{i.currentStock}</td><td>{i.minStockLevel}</td></tr>)}</Table>:<Empty title="Stock levels healthy" body="No low-stock items in this report."/ >}</section></div></>}</main>;
}

type EmployeeForm = { employeeId: string; fullName: string; email: string; department: string; region: string; role: Employee['role']; extraRegions: string[]; password: string };
const EMPTY_EMPLOYEE_FORM: EmployeeForm = { employeeId: '', fullName: '', email: '', department: '', region: '', role: 'Technician', extraRegions: [], password: '' };
const EMPLOYEE_ROLES: Employee['role'][] = ['Technician', 'Supervisor', 'Storekeeper', 'Manager', 'Admin'];
const ROLE_NOTES: Record<Employee['role'], string> = {
  Technician: 'Works on assigned job cards.',
  Supervisor: 'Reviews requests and manages job cards in their regions.',
  Storekeeper: 'Runs the warehouse desk for their regions.',
  Manager: 'Read-only view of every region (requests, job cards, inventory, reports).',
  Admin: 'Manages employee accounts and verifies requesters.',
};
function generatePassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  const bytes = new Uint32Array(14); window.crypto.getRandomValues(bytes);
  return Array.from(bytes, value => chars[value % chars.length]).join('');
}

function Employees(){
  const {employee:me}=useApp();const qc=useQueryClient();
  const employees=useListEmployees({query:{queryKey:getListEmployeesQueryKey()}});
  const regionsQ=useListRegions({query:{queryKey:getListRegionsQueryKey()}});
  const addEmployee=useCreateEmployee();const updateEmployee=useUpdateEmployee();const removeEmployee=useDeleteEmployee();
  const [search,setSearch]=useState('');const [open,setOpen]=useState(false);const [editing,setEditing]=useState<Employee|null>(null);
  const [form,setForm]=useState<EmployeeForm>(EMPTY_EMPLOYEE_FORM);
  const [formError,setFormError]=useState('');const [pageError,setPageError]=useState('');const [message,setMessage]=useState('');
  const people=employees.data??[];const knownRegions=regionsQ.data??[];
  const term=search.trim().toLowerCase();
  const shown=people.filter(p=>!term||`${p.employeeId} ${p.fullName} ${p.email}`.toLowerCase().includes(term));
  const patch=(change:Partial<EmployeeForm>)=>setForm(current=>({...current,...change}));

  // Duplicate checks run while typing, so the administrator is warned before saving.
  const idKey=form.employeeId.trim().toLowerCase();const emailKey=form.email.trim().toLowerCase();const nameKey=form.fullName.trim().toLowerCase();
  const dupId=!editing&&idKey?people.find(p=>p.employeeId.toLowerCase()===idKey):undefined;
  const dupEmail=emailKey?people.find(p=>p.email.toLowerCase()===emailKey&&p.employeeId!==editing?.employeeId):undefined;
  const dupName=nameKey.length>1?people.find(p=>p.fullName.trim().toLowerCase()===nameKey&&p.employeeId!==editing?.employeeId):undefined;
  const blocked=Boolean(dupId||dupEmail);
  const isManager=form.role==='Manager';

  const openCreate=()=>{setEditing(null);setForm(EMPTY_EMPLOYEE_FORM);setFormError('');setOpen(true);};
  const openEdit=(person:Employee)=>{setEditing(person);setForm({employeeId:person.employeeId,fullName:person.fullName,email:person.email,department:person.department,region:person.region,role:person.role,extraRegions:person.regions.filter(r=>r!==person.region),password:''});setFormError('');setOpen(true);};
  const close=()=>{setOpen(false);setEditing(null);};
  const refresh=()=>Promise.all([qc.invalidateQueries({queryKey:getListEmployeesQueryKey()}),qc.invalidateQueries({queryKey:getListRegionsQueryKey()})]);

  const save=async(e:FormEvent)=>{
    e.preventDefault();setFormError('');setMessage('');setPageError('');
    if(blocked)return;
    const primary=form.region.trim();
    const regionList=isManager?[primary]:Array.from(new Set([primary,...form.extraRegions.map(r=>r.trim()).filter(Boolean)]));
    try{
      if(editing){
        await updateEmployee.mutateAsync({employeeId:editing.employeeId,data:{fullName:form.fullName.trim(),email:form.email.trim(),department:form.department.trim(),region:primary,role:form.role,regions:regionList,temporaryPassword:form.password||undefined}});
        setMessage(form.password?`${form.fullName.trim()} was updated. Temporary password: ${form.password} — share it privately. It must be changed at the next sign-in and all their current sessions were ended.`:`${form.fullName.trim()} was updated.`);
      }else{
        await addEmployee.mutateAsync({data:{employeeId:form.employeeId.trim(),fullName:form.fullName.trim(),email:form.email.trim(),department:form.department.trim(),region:primary,role:form.role,temporaryPassword:form.password,regions:regionList}});
        setMessage(`${form.fullName.trim()} was added. Temporary password: ${form.password} — share it privately. It must be changed at first sign-in.`);
      }
      await refresh();close();
    }catch(error){setFormError(apiMessage(error,'Unable to save this employee.'));}
  };
  const remove=async(person:Employee)=>{
    if(!window.confirm(`Delete ${person.fullName} (${person.employeeId})? This cannot be undone.`))return;
    setMessage('');setPageError('');
    try{await removeEmployee.mutateAsync({employeeId:person.employeeId});await refresh();setMessage(`${person.fullName} was deleted.`);}
    catch(error){setPageError(apiMessage(error,'Unable to delete this employee.'));}
  };

  return <main className="page-wrap">
    <PageHeading eyebrow="ADMINISTRATION / ACCOUNTS" title="Employee accounts" subtitle="Add, edit, search and remove team members. New accounts get a temporary password that must be changed at first sign-in." action={<button className="button primary" onClick={openCreate} data-testid="button-add-employee"><Plus size={15}/> Add employee</button>}/>
    {message&&<div className="alert-box success" role="status" style={{marginBottom:14,wordBreak:'break-word'}}><Check size={16}/>{message}</div>}
    {pageError&&<div className="alert-box" role="alert" style={{marginBottom:14}}><AlertTriangle size={16}/>{pageError}</div>}
    <section className="panel">
      <div className="panel-head"><SearchBox value={search} onChange={setSearch} placeholder="Search by employee ID, name or email"/><span className="badge blue">{shown.length} of {people.length}</span></div>
      {employees.isLoading?<div className="panel-content"><LoadingPanel count={2}/></div>:employees.isError?<div className="panel-content"><ErrorPanel retry={()=>void employees.refetch()}/></div>:shown.length?<Table headers={['Employee','ID','Department','Regions','Role','']} minWidth={780}>{shown.map(person=><tr key={person.employeeId}><td><b>{person.fullName}</b><div style={{fontSize:10,color:'#86918c'}}>{person.email}</div></td><td className="font-mono">{person.employeeId}</td><td>{person.department}</td><td>{person.role==='Manager'?'All regions (read-only)':person.regions.join(', ')}</td><td><Badge text={person.role}/></td><td><div className="table-actions"><button className="button outline small" onClick={()=>openEdit(person)} data-testid={`button-edit-${person.employeeId}`}>Edit</button><button className="button outline small danger" disabled={person.employeeId===me.employeeId||removeEmployee.isPending} title={person.employeeId===me.employeeId?'You cannot delete your own account':'Delete employee'} onClick={()=>void remove(person)} data-testid={`button-delete-${person.employeeId}`}>Delete</button></div></td></tr>)}</Table>:<Empty title={term?'No employees match your search':'No employees listed'} body={term?'Try another employee ID, name or email.':'Employee accounts will appear here after they are created.'}/>}
    </section>
    {open&&<Modal title={editing?`Edit ${editing.fullName}`:'Add employee'} close={close}><form onSubmit={save}>
      <div className="field-grid">
        <div className="field"><label htmlFor="employee-id">Employee ID</label><input id="employee-id" className="input" required minLength={2} value={form.employeeId} disabled={Boolean(editing)} onChange={e=>patch({employeeId:e.target.value})}/></div>
        <div className="field"><label htmlFor="employee-name">Full name</label><input id="employee-name" className="input" required minLength={2} value={form.fullName} onChange={e=>patch({fullName:e.target.value})}/></div>
        <div className="field"><label htmlFor="employee-email">Work email</label><input id="employee-email" className="input" type="email" required value={form.email} onChange={e=>patch({email:e.target.value})}/></div>
        <div className="field"><label htmlFor="employee-department">Department</label><input id="employee-department" className="input" required value={form.department} onChange={e=>patch({department:e.target.value})}/></div>
        <div className="field"><label htmlFor="employee-region">Primary region</label><input id="employee-region" className="input" list="mps-known-regions" required value={form.region} onChange={e=>patch({region:e.target.value})} placeholder="Choose or type a region"/><datalist id="mps-known-regions">{knownRegions.map(r=><option key={r} value={r}/>)}</datalist></div>
        <div className="field"><label htmlFor="employee-role">Category / role</label><select id="employee-role" className="select" value={form.role} onChange={e=>patch({role:e.target.value as Employee['role']})}>{EMPLOYEE_ROLES.map(r=><option key={r} value={r}>{r}</option>)}</select><small>{ROLE_NOTES[form.role]}</small></div>
      </div>
      {isManager?<div className="alert-box" style={{marginTop:14}}><ShieldCheck size={16}/>Managers can view every region and switch between them. They cannot change anything.</div>:<div className="field" style={{marginTop:14}}><label>Additional regions <span style={{fontWeight:400}}>— they can switch between these in the top bar</span></label><div style={{display:'flex',flexWrap:'wrap',gap:'6px 16px',padding:8,border:'1px solid #e4dfd4',borderRadius:8}}>{knownRegions.filter(r=>r!==form.region.trim()).map(r=><label key={r} style={{display:'flex',gap:6,alignItems:'center',fontSize:12}}><input type="checkbox" checked={form.extraRegions.includes(r)} onChange={e=>patch({extraRegions:e.target.checked?[...form.extraRegions,r]:form.extraRegions.filter(x=>x!==r)})}/>{r}</label>)}{!knownRegions.filter(r=>r!==form.region.trim()).length&&<span className="stat-note">No other regions exist yet.</span>}</div></div>}
      <div className="field" style={{marginTop:14}}><label htmlFor="employee-password">{editing?'New temporary password (optional)':'Temporary password'}</label><div style={{display:'flex',gap:8}}><input id="employee-password" className="input" type="text" autoComplete="off" spellCheck={false} required={!editing} minLength={12} maxLength={128} value={form.password} onChange={e=>patch({password:e.target.value})} placeholder={editing?'Leave blank to keep the current password':'At least 12 characters'}/><button type="button" className="button outline small" onClick={()=>patch({password:generatePassword()})}>Generate</button></div><small>{editing?'Setting one resets their access: they must choose a new password at next sign-in and their current sessions end.':'The employee must replace it at first sign-in.'}</small></div>
      {dupId&&<div className="alert-box" role="alert" style={{marginTop:14}}><AlertTriangle size={16}/><div><b>Duplicate employee ID.</b> {dupId.employeeId} already belongs to {dupId.fullName}. Edit that employee instead of adding a new one.</div></div>}
      {dupEmail&&<div className="alert-box" role="alert" style={{marginTop:10}}><AlertTriangle size={16}/><div><b>Duplicate email.</b> {dupEmail.email} is already registered to {dupEmail.fullName} ({dupEmail.employeeId}).</div></div>}
      {!blocked&&dupName&&<div className="alert-box" style={{marginTop:10}}><AlertTriangle size={16}/><div>Another employee has the same name: {dupName.fullName} ({dupName.employeeId}). Check this is not a duplicate before saving.</div></div>}
      {formError&&<div className="alert-box" role="alert" style={{marginTop:10}}><AlertTriangle size={16}/>{formError}</div>}
      <div style={{display:'flex',justifyContent:'flex-end',gap:8,marginTop:18}}><button type="button" className="button outline" onClick={close}>Cancel</button><button className="button primary" disabled={blocked||addEmployee.isPending||updateEmployee.isPending}>{addEmployee.isPending||updateEmployee.isPending?'Saving…':editing?'Save changes':'Add employee'}</button></div>
    </form></Modal>}
  </main>;
}


function Router(){return <ErrorBoundary><Switch>
  <Route path="/" component={PublicDashboardRedirect}/>
  <Route path="/request" component={PublicRequest}/>
  <Route path="/sign-in/*?" component={SignInPage}/>
  <Route path="/change-password" component={ChangePasswordPage}/>
  <Route path="/dashboard"><Protected><Workspace/></Protected></Route>
  <Route path="/inventory"><Protected><Workspace/></Protected></Route>
  <Route path="/storekeeper"><Protected><Workspace/></Protected></Route>
  <Route path="/requests"><Protected><Workspace/></Protected></Route>
  <Route path="/job-cards"><Protected><Workspace/></Protected></Route>
  <Route path="/reports"><Protected><Workspace/></Protected></Route>
  <Route path="/admin/employees"><Protected><Workspace/></Protected></Route>
  <Route component={NotFound}/>
</Switch></ErrorBoundary>}
function App(){return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={basePath}><Router/></WouterRouter><Toaster/></TooltipProvider></QueryClientProvider>}
export default App;
