# MPS — TD Project Structure

This guide describes the repository-owned files and folders. Dependency installs (`node_modules`), build output (`dist`), TypeScript incremental caches, Git internals, and Replit-managed skill files are generated or platform-managed and are intentionally not listed as source files. The root `zipFile.zip` is the uploaded source archive; the running app uses the extracted workspace files described here.

## Repository map

```text
.
├── artifacts/
│   ├── api-server/       Express API, Prisma schema, local auth, and storage
│   ├── mockup-sandbox/   Isolated UI component preview
│   └── mps-td/           Main React application
├── docs/                 Project documentation
├── lib/
│   ├── api-client-react/ Generated React Query API client
│   ├── api-spec/         OpenAPI source contract and generator config
│   ├── api-zod/          Generated validation schemas and API types
│   └── db/               Shared Drizzle package
├── scripts/              Workspace maintenance scripts
└── root configuration    pnpm, TypeScript, Replit, and Git settings
```

## Root files

| Path | Purpose |
| --- | --- |
| `.agents/memory/MEMORY.md` | Index of durable, project-specific agent notes; currently empty. |
| `.gitignore` | Excludes dependencies, build output, local configuration, and other generated files from Git. |
| `.npmrc` | pnpm/npm configuration used by the workspace. |
| `.replit` | Replit run and development environment configuration. |
| `.replitignore` | Files excluded from Replit deployment and project packaging. |
| `package.json` | Root workspace scripts for build and typechecking. |
| `pnpm-lock.yaml` | Exact resolved dependency versions for repeatable installs. |
| `pnpm-workspace.yaml` | Workspace package locations, shared dependency catalog, and package-manager policies. |
| `replit.md` | Run instructions, required environment, architecture notes, and operational guidance. |
| `tsconfig.base.json` | Shared TypeScript compiler options inherited by workspace packages. |
| `tsconfig.json` | Root TypeScript project references and build entry point. |
| `docs/PROJECT_STRUCTURE.md` | This file-by-file and folder-by-folder guide. |

## API server — `artifacts/api-server`

### Configuration and database files

| Path | Purpose |
| --- | --- |
| `.replit-artifact/artifact.toml` | Registers the API artifact, preview route, and managed service settings. |
| `build.mjs` | Bundles the TypeScript API entry point for the server runtime. |
| `package.json` | API scripts and dependencies, including Prisma, Express, pino, and storage clients. |
| `tsconfig.json` | API TypeScript settings and references to shared workspace packages. |
| `prisma/schema.prisma` | PostgreSQL source of truth for employees, sessions, jobs, requests, inventory, and requester verification status. The legacy `OtpChallenge` table is kept unused so `db push` needs no data-loss flag. |
| `prisma/migrations/migration_lock.toml` | Records the Prisma migration provider. |
| `prisma/migrations/20261106123219_init/migration.sql` | Original baseline database migration; kept as historical schema history. |
| `prisma/seed.mjs` | Inserts or updates sample employees, locations, inventory, and operational demo records. It does not set passwords. |
| `prisma/provision-test-account.mjs` | Creates a development-only test administrator, stores a scrypt password hash, and prints a one-time temporary password. |

### API source — `artifacts/api-server/src`

| Path | Purpose |
| --- | --- |
| `app.ts` | Creates the Express app and installs request logging, CORS, cookie parsing, JSON parsing, and API routes. |
| `index.ts` | Validates the required `PORT` setting and starts the HTTP server. |
| `lib/.gitkeep` | Keeps the shared server utility directory in Git. |
| `lib/auth.ts` | Scrypt password hashing, session-token hashing, cookie setup, session lookup, and safe employee serialization. |
| `lib/logger.ts` | Shared pino logger with sensitive request and response fields redacted. |
| `lib/objectAcl.ts` | Object-storage access-control helpers. |
| `lib/objectStorage.ts` | Object upload, download, and lookup integration. |
| `lib/prisma.ts` | Shared Prisma client instance. |
| `middlewares/.gitkeep` | Keeps the middleware directory available for future API middleware. |
| `routes/auth.ts` | Local sign-in, current-session, sign-out, and temporary-password replacement endpoints. |
| `routes/health.ts` | Health-check endpoint. |
| `routes/index.ts` | Mounts auth, health, MPS business, and storage routers. |
| `routes/mps.ts` | Maintenance, employee, inventory, warehouse, job-card, reports, media, employee CRUD, region lists and requester verification endpoints. |
| `routes/storage.ts` | Serves public objects and session-protected private objects. |

## Main web application — `artifacts/mps-td`

### App configuration and public assets

| Path | Purpose |
| --- | --- |
| `.replit-artifact/artifact.toml` | Registers the main web artifact, its preview route, and managed workflow. |
| `components.json` | shadcn/ui component-generation settings. |
| `index.html` | Vite HTML entry point with English document language metadata. |
| `package.json` | Web scripts and React, Vite, UI, chart, form, and API-client dependencies. |
| `tsconfig.json` | Web TypeScript settings, aliases, and API-client project reference. |
| `vite.config.ts` | Vite plugins, local development server, and app base-path settings. |
| `public/favicon.svg` | Browser tab icon. |
| `public/logo.svg` | MPS — TD logo used in the public and sign-in interfaces. |
| `public/robots.txt` | Search crawler instructions. |

### Application source — `artifacts/mps-td/src`

| Path | Purpose |
| --- | --- |
| `App.tsx` | Main UI: public home and the no-code requester flow (pending until an Admin verifies the email), local sign-in, password change, role-protected workspace routes, employee account management, and operations screens. |
| `index.css` | Design tokens, layout, responsive styling, typography, and component styles. |
| `main.tsx` | React entry point; mounts the application and global styles. |
| `components/error-boundary.tsx` | Catches rendering errors and displays the app recovery state. |
| `hooks/use-mobile.tsx` | Detects the current viewport's mobile breakpoint. |
| `hooks/use-toast.ts` | Provides toast state and notification helpers. |
| `lib/utils.ts` | Shared class-name and UI utility functions. |
| `pages/not-found.tsx` | English 404 page for unknown routes. |

### UI component files

The same component set is present under both `artifacts/mps-td/src/components/ui/` and `artifacts/mockup-sandbox/src/components/ui/`. Each row therefore documents the matching file in **both** component folders.

| File under each `src/components/ui/` folder | Purpose |
| --- | --- |
| `accordion.tsx` | Expandable, vertically stacked disclosure panels. |
| `alert-dialog.tsx` | Modal confirmation dialog for actions requiring a decision. |
| `alert.tsx` | Inline alert message and alert variants. |
| `aspect-ratio.tsx` | Container that preserves a chosen content aspect ratio. |
| `avatar.tsx` | Profile image, fallback initials, and avatar group primitives. |
| `badge.tsx` | Compact status and category labels. |
| `breadcrumb.tsx` | Hierarchical page-navigation trail. |
| `button-group.tsx` | Connected group of related actions or controls. |
| `button.tsx` | Shared button variants and interaction styles. |
| `calendar.tsx` | Date-picker calendar based on React Day Picker, formatted in English. |
| `card.tsx` | Card, header, content, footer, and title primitives. |
| `carousel.tsx` | Carousel controls and slide-content wrappers. |
| `chart.tsx` | Recharts wrappers, tooltips, legends, and chart styling. |
| `checkbox.tsx` | Accessible checkbox control. |
| `collapsible.tsx` | Single expandable content region. |
| `command.tsx` | Searchable command menu and command-list primitives. |
| `context-menu.tsx` | Pointer-triggered context menu. |
| `dialog.tsx` | Modal dialog and overlay primitives. |
| `drawer.tsx` | Mobile-oriented drawer panel. |
| `dropdown-menu.tsx` | Action menu opened from a trigger. |
| `empty.tsx` | Empty-state content layout. |
| `field.tsx` | Form field, label, description, and error layout. |
| `form.tsx` | Form integration and validation-message components. |
| `hover-card.tsx` | Content panel shown on hover or focus. |
| `input-group.tsx` | Input with attached controls or adornments. |
| `input-otp.tsx` | One-time-code input slots. |
| `input.tsx` | Styled text-entry input. |
| `item.tsx` | Reusable item row and grouped item layouts. |
| `kbd.tsx` | Keyboard shortcut key styling. |
| `label.tsx` | Accessible form label. |
| `menubar.tsx` | Horizontal menu bar with nested actions. |
| `navigation-menu.tsx` | Site navigation menu with submenu primitives. |
| `pagination.tsx` | Page navigation controls for lists. |
| `popover.tsx` | Anchored floating content panel. |
| `progress.tsx` | Progress indicator. |
| `radio-group.tsx` | Mutually exclusive radio choices. |
| `resizable.tsx` | Resizable panel group and handles. |
| `scroll-area.tsx` | Styled, customizable scroll container. |
| `select.tsx` | Accessible dropdown selection control. |
| `separator.tsx` | Visual divider. |
| `sheet.tsx` | Side or bottom overlay panel. |
| `sidebar.tsx` | Sidebar navigation and responsive sidebar primitives. |
| `skeleton.tsx` | Loading placeholder shapes. |
| `slider.tsx` | Range slider control. |
| `sonner.tsx` | Sonner toast-notification integration. |
| `spinner.tsx` | Loading spinner. |
| `switch.tsx` | Toggle switch control. |
| `table.tsx` | Table, row, cell, header, and caption primitives. |
| `tabs.tsx` | Tab list, tab trigger, and tab content. |
| `textarea.tsx` | Styled multi-line text input. |
| `toaster.tsx` | Global toast container. |
| `toast.tsx` | Toast notification and action primitives. |
| `toggle-group.tsx` | Mutually exclusive or multi-select toggle buttons. |
| `toggle.tsx` | Single pressed/unpressed toggle button. |
| `tooltip.tsx` | Tooltip provider, trigger, and content. |

## Component preview app — `artifacts/mockup-sandbox`

| Path | Purpose |
| --- | --- |
| `.replit-artifact/artifact.toml` | Registers the isolated design-preview artifact and service. |
| `components.json` | shadcn/ui configuration for preview components. |
| `index.html` | HTML entry point for the component preview. |
| `mockupPreviewPlugin.ts` | Vite plugin used by the mockup preview environment. |
| `package.json` | Preview app scripts and dependencies. |
| `tsconfig.json` | Preview app TypeScript settings. |
| `vite.config.ts` | Vite config for the preview server and mockup plugin. |
| `src/App.tsx` | Preview shell that renders generated component previews. |
| `src/.generated/mockup-components.ts` | Generated registry of previewable components. |
| `src/index.css` | Preview app styling and shared UI theme tokens. |
| `src/main.tsx` | React entry point for the preview app. |
| `src/hooks/use-mobile.tsx` | Mobile viewport detection hook. |
| `src/hooks/use-toast.ts` | Toast state and notification helper. |
| `src/lib/utils.ts` | Shared class-name and UI helpers. |

## Shared API packages

### `lib/api-spec`

| Path | Purpose |
| --- | --- |
| `package.json` | API contract code-generation command and Orval dependency. |
| `orval.config.ts` | Orval output configuration for the React client and Zod package. |
| `openapi.yaml` | Source API contract for auth, health, maintenance, workforce, inventory, reporting, storage, and requester email-verification operations. |

### `lib/api-client-react`

| Path | Purpose |
| --- | --- |
| `package.json` | Workspace package metadata and peer dependencies. |
| `tsconfig.json` | TypeScript settings for the API client. |
| `src/index.ts` | Public exports for generated hooks and request configuration. |
| `src/custom-fetch.ts` | Shared fetch transport, base URL handling, errors, and optional bearer-token hook. |
| `src/generated/api.ts` | Generated API functions, query keys, and React Query hooks. |
| `src/generated/api.schemas.ts` | Generated client-side Zod response and input schemas. |

### `lib/api-zod`

| Path | Purpose |
| --- | --- |
| `package.json` | Workspace package metadata for generated API validators. |
| `tsconfig.json` | TypeScript settings for the validation package. |
| `src/index.ts` | Public exports for generated validators and types. |
| `src/generated/api.ts` | Generated Zod schemas for API inputs and responses. |
| `src/generated/types/index.ts` | Barrel exports for generated API types. |

Each file below defines a generated TypeScript type for the correspondingly named API object:

| Path under `lib/api-zod/src/generated/types/` | API data represented |
| --- | --- |
| `activeJob.ts` | Active job-card summary. |
| `authSession.ts` | Authenticated employee and first-login password state. |
| `changePasswordInput.ts` | Current and replacement password input. |
| `dashboardSummaryJobStatusBreakdownItem.ts` | One job-status count in dashboard summaries. |
| `dashboardSummary.ts` | Operations dashboard metrics and recent requests. |
| `employeeInputRole.ts` | Allowed employee roles for account creation. |
| `employeeInput.ts` | Employee details and temporary account password. |
| `employeeRole.ts` | Role value on an employee response. |
| `employee.ts` | Employee profile and accessible regions. |
| `getMpsReportsParams.ts` | Filters for operations reports. |
| `healthStatus.ts` | API health response. |
| `inventoryItem.ts` | Inventory item with stock and valuation. |
| `itemInput.ts` | New inventory item input. |
| `itemUpdate.ts` | Editable inventory item fields. |
| `jobCardInput.ts` | New job-card input. |
| `jobCard.ts` | Job-card response and assigned technicians. |
| `jobCardUpdate.ts` | Job-card status, assignment, and report changes. |
| `listJobCardsParams.ts` | Job-card list filters. |
| `listMaintenanceRequestsParams.ts` | Maintenance-request list filters. |
| `listTransactionsParams.ts` | Warehouse-transaction list filters. |
| `listTransactionsType.ts` | Supported warehouse transaction filter values. |
| `location.ts` | Approved maintenance location. |
| `loginInput.ts` | Local email and temporary-password sign-in input. |
| `maintenanceRequestInput.ts` | Public maintenance-request submission input. |
| `maintenanceRequest.ts` | Maintenance request response and attached job-card IDs. |
| `mediaFile.ts` | Uploaded media metadata. |
| `purchaseSummary.ts` | Item purchase-history summary. |
| `reportsDataTechnicianPerformanceItem.ts` | Technician performance report row. |
| `reportsData.ts` | Operations report response. |
| `requesterEmailInput.ts` | Requester email lookup input. |
| `requester.ts` | Requester record with verification status and waiting requests. |
| `requesterLookup.ts` | Whether an email is new, pending, verified or rejected. |
| `employeeUpdate.ts` | Partial employee edit input (optionally with a new temporary password). |
| `requestUpdateStatus.ts` | Maintenance request status value. |
| `requestUpdate.ts` | Maintenance request update input. |
| `transactionInputPurchaseType.ts` | Warehouse purchase type values. |
| `transactionInputTransactionType.ts` | Warehouse movement type values. |
| `transactionInput.ts` | Warehouse transaction creation input. |
| `uploadRequestPurpose.ts` | Media upload purpose values. |
| `uploadRequest.ts` | Signed media upload request input. |
| `uploadUrl.ts` | Signed media upload URL response. |
| `verifiedRequester.ts` | Verified requester session result. |
| `warehouseTransactionTransactionType.ts` | Warehouse movement type on a transaction. |
| `warehouseTransaction.ts` | Warehouse ledger response row. |
| `whitelistCheck.ts` | Approved requester lookup result. |

## Shared database package — `lib/db`

| Path | Purpose |
| --- | --- |
| `drizzle.config.ts` | Drizzle Kit database and schema configuration. |
| `package.json` | Shared database package scripts and dependencies. |
| `tsconfig.json` | TypeScript settings for the shared database package. |
| `src/index.ts` | Public exports for the Drizzle client and schema. |
| `src/schema/index.ts` | Barrel exports for Drizzle schema modules. |

This package is part of the monorepo, but the MPS API currently uses the Prisma schema in `artifacts/api-server/prisma/schema.prisma`.

## Workspace scripts — `scripts`

| Path | Purpose |
| --- | --- |
| `package.json` | Script package metadata. |
| `post-merge.sh` | Runs workspace setup tasks after a merge. |
| `src/hello.ts` | Small TypeScript example entry point. |
| `tsconfig.json` | Script-package TypeScript settings. |

## Data and security notes

- `EmployeeWhitelist.passwordHash` stores scrypt hashes, not temporary or permanent passwords in plain text.
- `AuthSession.tokenHash` stores a keyed hash of the opaque cookie token; the raw token remains in an HTTP-only cookie.
- The development provisioning script resets only its dedicated test administrator and refuses `NODE_ENV=production`.
- The current Prisma schema no longer contains the bilingual `AppTranslation` model. Applying the schema drops that table and its old translation rows.
- The initial Prisma migration remains in place as historical baseline history; it is not the current schema definition.
